window.histograms = {
 "states": [
  {
   "hits": 8912, 
   "name": "other"
  }, 
  {
   "hits": 4621, 
   "name": "ca"
  }, 
  {
   "hits": 2054, 
   "name": "ny"
  }, 
  {
   "hits": 1393, 
   "name": "ma"
  }, 
  {
   "hits": 1306, 
   "name": "tx"
  }, 
  {
   "hits": 1091, 
   "name": "il"
  }, 
  {
   "hits": 1020, 
   "name": "wa"
  }, 
  {
   "hits": 961, 
   "name": "fl"
  }, 
  {
   "hits": 791, 
   "name": "pa"
  }, 
  {
   "hits": 656, 
   "name": "va"
  }, 
  {
   "hits": 629, 
   "name": "nj"
  }, 
  {
   "hits": 597, 
   "name": "or"
  }, 
  {
   "hits": 547, 
   "name": "oh"
  }, 
  {
   "hits": 547, 
   "name": "mi"
  }, 
  {
   "hits": 517, 
   "name": "co"
  }, 
  {
   "hits": 517, 
   "name": "md"
  }, 
  {
   "hits": 516, 
   "name": "nc"
  }, 
  {
   "hits": 457, 
   "name": "ga"
  }, 
  {
   "hits": 393, 
   "name": "mn"
  }, 
  {
   "hits": 387, 
   "name": "az"
  }, 
  {
   "hits": 325, 
   "name": "in"
  }, 
  {
   "hits": 321, 
   "name": "wi"
  }, 
  {
   "hits": 300, 
   "name": "mo"
  }, 
  {
   "hits": 265, 
   "name": "tn"
  }, 
  {
   "hits": 244, 
   "name": "ct"
  }, 
  {
   "hits": 207, 
   "name": "dc"
  }, 
  {
   "hits": 202, 
   "name": "ut"
  }, 
  {
   "hits": 162, 
   "name": "nm"
  }, 
  {
   "hits": 146, 
   "name": "ks"
  }, 
  {
   "hits": 144, 
   "name": "ky"
  }, 
  {
   "hits": 143, 
   "name": "ok"
  }, 
  {
   "hits": 143, 
   "name": "sc"
  }, 
  {
   "hits": 135, 
   "name": "la"
  }, 
  {
   "hits": 131, 
   "name": "nv"
  }, 
  {
   "hits": 122, 
   "name": "ia"
  }, 
  {
   "hits": 119, 
   "name": "nh"
  }, 
  {
   "hits": 118, 
   "name": "al"
  }, 
  {
   "hits": 113, 
   "name": "ar"
  }, 
  {
   "hits": 110, 
   "name": "me"
  }, 
  {
   "hits": 93, 
   "name": "hi"
  }, 
  {
   "hits": 91, 
   "name": "ne"
  }, 
  {
   "hits": 77, 
   "name": "id"
  }, 
  {
   "hits": 77, 
   "name": "ri"
  }, 
  {
   "hits": 75, 
   "name": "vt"
  }, 
  {
   "hits": 67, 
   "name": "mt"
  }, 
  {
   "hits": 65, 
   "name": "wv"
  }, 
  {
   "hits": 59, 
   "name": "de"
  }, 
  {
   "hits": 56, 
   "name": "ak"
  }, 
  {
   "hits": 52, 
   "name": "ms"
  }, 
  {
   "hits": 36, 
   "name": "wy"
  }, 
  {
   "hits": 32, 
   "name": "sd"
  }, 
  {
   "hits": 31, 
   "name": "nd"
  }, 
  {
   "hits": 13, 
   "name": "pr"
  }, 
  {
   "hits": 2, 
   "name": "as"
  }
 ], 
 "cities": [
  {
   "hits": 11643, 
   "name": "other"
  }, 
  {
   "hits": 678, 
   "name": "san francisco, ca"
  }, 
  {
   "hits": 619, 
   "name": "new york, ny"
  }, 
  {
   "hits": 431, 
   "name": "brooklyn, ny"
  }, 
  {
   "hits": 426, 
   "name": "seattle, wa"
  }, 
  {
   "hits": 423, 
   "name": "chicago, il"
  }, 
  {
   "hits": 364, 
   "name": "los angeles, ca"
  }, 
  {
   "hits": 295, 
   "name": "portland, or"
  }, 
  {
   "hits": 278, 
   "name": "austin, tx"
  }, 
  {
   "hits": 207, 
   "name": "washington, dc"
  }, 
  {
   "hits": 205, 
   "name": "san diego, ca"
  }, 
  {
   "hits": 193, 
   "name": "cambridge, ma"
  }, 
  {
   "hits": 183, 
   "name": "houston, tx"
  }, 
  {
   "hits": 156, 
   "name": "san jose, ca"
  }, 
  {
   "hits": 154, 
   "name": "atlanta, ga"
  }, 
  {
   "hits": 153, 
   "name": "oakland, ca"
  }, 
  {
   "hits": 153, 
   "name": "philadelphia, pa"
  }, 
  {
   "hits": 151, 
   "name": "minneapolis, mn"
  }, 
  {
   "hits": 135, 
   "name": "denver, co"
  }, 
  {
   "hits": 132, 
   "name": "boston, ma"
  }, 
  {
   "hits": 117, 
   "name": "berkeley, ca"
  }, 
  {
   "hits": 101, 
   "name": "miami, fl"
  }, 
  {
   "hits": 99, 
   "name": "somerville, ma"
  }, 
  {
   "hits": 97, 
   "name": "pittsburgh, pa"
  }, 
  {
   "hits": 94, 
   "name": "mountain view, ca"
  }, 
  {
   "hits": 89, 
   "name": "saint louis, mo"
  }, 
  {
   "hits": 89, 
   "name": "san antonio, tx"
  }, 
  {
   "hits": 86, 
   "name": "tucson, az"
  }, 
  {
   "hits": 84, 
   "name": "phoenix, az"
  }, 
  {
   "hits": 83, 
   "name": "saint paul, mn"
  }, 
  {
   "hits": 83, 
   "name": "madison, wi"
  }, 
  {
   "hits": 82, 
   "name": "baltimore, md"
  }, 
  {
   "hits": 81, 
   "name": "dallas, tx"
  }, 
  {
   "hits": 76, 
   "name": "palo alto, ca"
  }, 
  {
   "hits": 74, 
   "name": "arlington, va"
  }, 
  {
   "hits": 73, 
   "name": "sacramento, ca"
  }, 
  {
   "hits": 70, 
   "name": "ann arbor, mi"
  }, 
  {
   "hits": 68, 
   "name": "raleigh, nc"
  }, 
  {
   "hits": 68, 
   "name": "cincinnati, oh"
  }, 
  {
   "hits": 67, 
   "name": "boulder, co"
  }, 
  {
   "hits": 66, 
   "name": "salt lake city, ut"
  }, 
  {
   "hits": 65, 
   "name": "orlando, fl"
  }, 
  {
   "hits": 64, 
   "name": "beverly hills, ca"
  }, 
  {
   "hits": 64, 
   "name": "las vegas, nv"
  }, 
  {
   "hits": 63, 
   "name": "indianapolis, in"
  }, 
  {
   "hits": 63, 
   "name": "columbus, oh"
  }, 
  {
   "hits": 57, 
   "name": "rochester, ny"
  }, 
  {
   "hits": 54, 
   "name": "sunnyvale, ca"
  }, 
  {
   "hits": 53, 
   "name": "tampa, fl"
  }, 
  {
   "hits": 53, 
   "name": "albuquerque, nm"
  }, 
  {
   "hits": 53, 
   "name": "bellevue, wa"
  }, 
  {
   "hits": 51, 
   "name": "nashville, tn"
  }, 
  {
   "hits": 50, 
   "name": "milwaukee, wi"
  }, 
  {
   "hits": 50, 
   "name": "durham, nc"
  }, 
  {
   "hits": 49, 
   "name": "eugene, or"
  }, 
  {
   "hits": 49, 
   "name": "alexandria, va"
  }, 
  {
   "hits": 48, 
   "name": "silver spring, md"
  }, 
  {
   "hits": 47, 
   "name": "santa monica, ca"
  }, 
  {
   "hits": 44, 
   "name": "jersey city, nj"
  }, 
  {
   "hits": 44, 
   "name": "santa clara, ca"
  }, 
  {
   "hits": 43, 
   "name": "kansas city, mo"
  }, 
  {
   "hits": 43, 
   "name": "richmond, va"
  }, 
  {
   "hits": 42, 
   "name": "new orleans, la"
  }, 
  {
   "hits": 42, 
   "name": "astoria, ny"
  }, 
  {
   "hits": 41, 
   "name": "irvine, ca"
  }, 
  {
   "hits": 41, 
   "name": "san mateo, ca"
  }, 
  {
   "hits": 41, 
   "name": "louisville, ky"
  }, 
  {
   "hits": 41, 
   "name": "pasadena, ca"
  }, 
  {
   "hits": 41, 
   "name": "cleveland, oh"
  }, 
  {
   "hits": 40, 
   "name": "bronx, ny"
  }, 
  {
   "hits": 39, 
   "name": "jacksonville, fl"
  }, 
  {
   "hits": 39, 
   "name": "omaha, ne"
  }, 
  {
   "hits": 39, 
   "name": "arlington, ma"
  }, 
  {
   "hits": 38, 
   "name": "santa cruz, ca"
  }, 
  {
   "hits": 38, 
   "name": "fremont, ca"
  }, 
  {
   "hits": 38, 
   "name": "santa barbara, ca"
  }, 
  {
   "hits": 38, 
   "name": "gainesville, fl"
  }, 
  {
   "hits": 37, 
   "name": "charlotte, nc"
  }, 
  {
   "hits": 37, 
   "name": "redmond, wa"
  }, 
  {
   "hits": 36, 
   "name": "redwood city, ca"
  }, 
  {
   "hits": 36, 
   "name": "fort worth, tx"
  }, 
  {
   "hits": 36, 
   "name": "beaverton, or"
  }, 
  {
   "hits": 35, 
   "name": "ithaca, ny"
  }, 
  {
   "hits": 35, 
   "name": "colorado springs, co"
  }, 
  {
   "hits": 35, 
   "name": "little rock, ar"
  }, 
  {
   "hits": 35, 
   "name": "buffalo, ny"
  }, 
  {
   "hits": 34, 
   "name": "tulsa, ok"
  }, 
  {
   "hits": 34, 
   "name": "honolulu, hi"
  }, 
  {
   "hits": 34, 
   "name": "rockville, md"
  }, 
  {
   "hits": 34, 
   "name": "providence, ri"
  }, 
  {
   "hits": 34, 
   "name": "bloomington, in"
  }, 
  {
   "hits": 34, 
   "name": "vancouver, wa"
  }, 
  {
   "hits": 33, 
   "name": "long beach, ca"
  }, 
  {
   "hits": 33, 
   "name": "mesa, az"
  }, 
  {
   "hits": 33, 
   "name": "fort lauderdale, fl"
  }, 
  {
   "hits": 33, 
   "name": "jamaica plain, ma"
  }, 
  {
   "hits": 33, 
   "name": "shawnee mission, ks"
  }, 
  {
   "hits": 32, 
   "name": "alameda, ca"
  }, 
  {
   "hits": 31, 
   "name": "chapel hill, nc"
  }, 
  {
   "hits": 30, 
   "name": "memphis, tn"
  }, 
  {
   "hits": 30, 
   "name": "oklahoma city, ok"
  }, 
  {
   "hits": 28, 
   "name": "tempe, az"
  }, 
  {
   "hits": 28, 
   "name": "boise, id"
  }, 
  {
   "hits": 28, 
   "name": "cupertino, ca"
  }, 
  {
   "hits": 28, 
   "name": "santa rosa, ca"
  }, 
  {
   "hits": 27, 
   "name": "brookline, ma"
  }, 
  {
   "hits": 27, 
   "name": "bellingham, wa"
  }, 
  {
   "hits": 27, 
   "name": "tallahassee, fl"
  }, 
  {
   "hits": 27, 
   "name": "olympia, wa"
  }, 
  {
   "hits": 27, 
   "name": "venice, ca"
  }, 
  {
   "hits": 27, 
   "name": "el paso, tx"
  }, 
  {
   "hits": 27, 
   "name": "santa fe, nm"
  }, 
  {
   "hits": 27, 
   "name": "north hollywood, ca"
  }, 
  {
   "hits": 26, 
   "name": "wichita, ks"
  }, 
  {
   "hits": 26, 
   "name": "grand rapids, mi"
  }, 
  {
   "hits": 26, 
   "name": "princeton, nj"
  }, 
  {
   "hits": 26, 
   "name": "charlottesville, va"
  }, 
  {
   "hits": 26, 
   "name": "asheville, nc"
  }, 
  {
   "hits": 26, 
   "name": "reno, nv"
  }, 
  {
   "hits": 26, 
   "name": "spokane, wa"
  }, 
  {
   "hits": 25, 
   "name": "fort collins, co"
  }, 
  {
   "hits": 25, 
   "name": "fairfax, va"
  }, 
  {
   "hits": 25, 
   "name": "corvallis, or"
  }, 
  {
   "hits": 25, 
   "name": "dayton, oh"
  }, 
  {
   "hits": 25, 
   "name": "littleton, co"
  }, 
  {
   "hits": 25, 
   "name": "champaign, il"
  }, 
  {
   "hits": 24, 
   "name": "menlo park, ca"
  }, 
  {
   "hits": 24, 
   "name": "scottsdale, az"
  }, 
  {
   "hits": 24, 
   "name": "evanston, il"
  }, 
  {
   "hits": 24, 
   "name": "watertown, ma"
  }, 
  {
   "hits": 24, 
   "name": "lincoln, ne"
  }, 
  {
   "hits": 24, 
   "name": "staten island, ny"
  }, 
  {
   "hits": 23, 
   "name": "glendale, ca"
  }, 
  {
   "hits": 23, 
   "name": "marietta, ga"
  }, 
  {
   "hits": 23, 
   "name": ", ca"
  }, 
  {
   "hits": 23, 
   "name": "newark, de"
  }, 
  {
   "hits": 23, 
   "name": "brighton, ma"
  }, 
  {
   "hits": 23, 
   "name": "oak park, il"
  }, 
  {
   "hits": 23, 
   "name": "chandler, az"
  }, 
  {
   "hits": 22, 
   "name": "iowa city, ia"
  }, 
  {
   "hits": 22, 
   "name": "tacoma, wa"
  }, 
  {
   "hits": 22, 
   "name": "falls church, va"
  }, 
  {
   "hits": 22, 
   "name": "medford, ma"
  }, 
  {
   "hits": 22, 
   "name": "aurora, co"
  }, 
  {
   "hits": 22, 
   "name": "clearwater, fl"
  }, 
  {
   "hits": 22, 
   "name": "gaithersburg, md"
  }, 
  {
   "hits": 22, 
   "name": "worcester, ma"
  }, 
  {
   "hits": 22, 
   "name": "anchorage, ak"
  }, 
  {
   "hits": 22, 
   "name": "virginia beach, va"
  }, 
  {
   "hits": 21, 
   "name": "saint petersburg, fl"
  }, 
  {
   "hits": 21, 
   "name": "chattanooga, tn"
  }, 
  {
   "hits": 21, 
   "name": "lexington, ma"
  }, 
  {
   "hits": 21, 
   "name": "cary, nc"
  }, 
  {
   "hits": 21, 
   "name": "walnut creek, ca"
  }, 
  {
   "hits": 21, 
   "name": "la jolla, ca"
  }, 
  {
   "hits": 20, 
   "name": "pompano beach, fl"
  }, 
  {
   "hits": 20, 
   "name": "kirkland, wa"
  }, 
  {
   "hits": 20, 
   "name": "pensacola, fl"
  }, 
  {
   "hits": 20, 
   "name": "lawrence, ks"
  }, 
  {
   "hits": 20, 
   "name": "plano, tx"
  }, 
  {
   "hits": 20, 
   "name": "new haven, ct"
  }, 
  {
   "hits": 20, 
   "name": "huntsville, al"
  }, 
  {
   "hits": 19, 
   "name": "emeryville, ca"
  }, 
  {
   "hits": 19, 
   "name": "reston, va"
  }, 
  {
   "hits": 19, 
   "name": "missoula, mt"
  }, 
  {
   "hits": 19, 
   "name": "fort wayne, in"
  }, 
  {
   "hits": 19, 
   "name": "lexington, ky"
  }, 
  {
   "hits": 19, 
   "name": "charleston, sc"
  }, 
  {
   "hits": 19, 
   "name": "naperville, il"
  }, 
  {
   "hits": 19, 
   "name": "belmont, ma"
  }, 
  {
   "hits": 19, 
   "name": "bethesda, md"
  }, 
  {
   "hits": 19, 
   "name": "allston, ma"
  }, 
  {
   "hits": 19, 
   "name": "columbia, mo"
  }, 
  {
   "hits": 19, 
   "name": "edison, nj"
  }, 
  {
   "hits": 19, 
   "name": "birmingham, al"
  }, 
  {
   "hits": 18, 
   "name": "broomfield, co"
  }, 
  {
   "hits": 18, 
   "name": "stanford, ca"
  }, 
  {
   "hits": 18, 
   "name": "hayward, ca"
  }, 
  {
   "hits": 18, 
   "name": "west palm beach, fl"
  }, 
  {
   "hits": 18, 
   "name": "los altos, ca"
  }, 
  {
   "hits": 18, 
   "name": "knoxville, tn"
  }, 
  {
   "hits": 18, 
   "name": "hoboken, nj"
  }, 
  {
   "hits": 17, 
   "name": "salem, or"
  }, 
  {
   "hits": 17, 
   "name": "ashburn, va"
  }, 
  {
   "hits": 17, 
   "name": "herndon, va"
  }, 
  {
   "hits": 17, 
   "name": "san rafael, ca"
  }, 
  {
   "hits": 17, 
   "name": "decatur, ga"
  }, 
  {
   "hits": 17, 
   "name": "bothell, wa"
  }, 
  {
   "hits": 17, 
   "name": "wilmington, de"
  }, 
  {
   "hits": 17, 
   "name": "nashua, nh"
  }, 
  {
   "hits": 17, 
   "name": "schenectady, ny"
  }, 
  {
   "hits": 17, 
   "name": "chico, ca"
  }, 
  {
   "hits": 17, 
   "name": "portland, me"
  }, 
  {
   "hits": 17, 
   "name": "natick, ma"
  }, 
  {
   "hits": 17, 
   "name": "albany, ny"
  }, 
  {
   "hits": 16, 
   "name": "los gatos, ca"
  }, 
  {
   "hits": 16, 
   "name": "springfield, va"
  }, 
  {
   "hits": 16, 
   "name": "newton center, ma"
  }, 
  {
   "hits": 16, 
   "name": "wilmington, nc"
  }, 
  {
   "hits": 16, 
   "name": "sherman oaks, ca"
  }, 
  {
   "hits": 16, 
   "name": "rochester, mn"
  }, 
  {
   "hits": 16, 
   "name": "roanoke, va"
  }, 
  {
   "hits": 16, 
   "name": "bakersfield, ca"
  }, 
  {
   "hits": 16, 
   "name": "trenton, nj"
  }, 
  {
   "hits": 16, 
   "name": "carrollton, tx"
  }, 
  {
   "hits": 16, 
   "name": "arlington, tx"
  }, 
  {
   "hits": 16, 
   "name": "waltham, ma"
  }, 
  {
   "hits": 16, 
   "name": "miami beach, fl"
  }, 
  {
   "hits": 15, 
   "name": "athens, ga"
  }, 
  {
   "hits": 15, 
   "name": "henderson, nv"
  }, 
  {
   "hits": 15, 
   "name": "kennesaw, ga"
  }, 
  {
   "hits": 15, 
   "name": "frederick, md"
  }, 
  {
   "hits": 15, 
   "name": "fresno, ca"
  }, 
  {
   "hits": 15, 
   "name": "norfolk, va"
  }, 
  {
   "hits": 15, 
   "name": "anaheim, ca"
  }, 
  {
   "hits": 15, 
   "name": "baton rouge, la"
  }, 
  {
   "hits": 15, 
   "name": "greensboro, nc"
  }, 
  {
   "hits": 15, 
   "name": "spring, tx"
  }, 
  {
   "hits": 15, 
   "name": "ypsilanti, mi"
  }, 
  {
   "hits": 15, 
   "name": "huntington beach, ca"
  }, 
  {
   "hits": 15, 
   "name": "mission viejo, ca"
  }, 
  {
   "hits": 14, 
   "name": "ellicott city, md"
  }, 
  {
   "hits": 14, 
   "name": "winston salem, nc"
  }, 
  {
   "hits": 14, 
   "name": "ames, ia"
  }, 
  {
   "hits": 14, 
   "name": "albany, ca"
  }, 
  {
   "hits": 14, 
   "name": "escondido, ca"
  }, 
  {
   "hits": 14, 
   "name": "costa mesa, ca"
  }, 
  {
   "hits": 14, 
   "name": "woodstock, ga"
  }, 
  {
   "hits": 14, 
   "name": "fargo, nd"
  }, 
  {
   "hits": 14, 
   "name": "blacksburg, va"
  }, 
  {
   "hits": 14, 
   "name": "columbia, sc"
  }, 
  {
   "hits": 14, 
   "name": "toledo, oh"
  }, 
  {
   "hits": 14, 
   "name": "orange, ca"
  }, 
  {
   "hits": 14, 
   "name": "richardson, tx"
  }, 
  {
   "hits": 14, 
   "name": "hillsboro, or"
  }, 
  {
   "hits": 14, 
   "name": "fayetteville, ar"
  }, 
  {
   "hits": 14, 
   "name": "sarasota, fl"
  }, 
  {
   "hits": 14, 
   "name": "state college, pa"
  }, 
  {
   "hits": 14, 
   "name": "riverside, ca"
  }, 
  {
   "hits": 14, 
   "name": "south bend, in"
  }, 
  {
   "hits": 14, 
   "name": "columbia, md"
  }, 
  {
   "hits": 14, 
   "name": "quincy, ma"
  }, 
  {
   "hits": 14, 
   "name": "novato, ca"
  }, 
  {
   "hits": 13, 
   "name": "boca raton, fl"
  }, 
  {
   "hits": 13, 
   "name": "katy, tx"
  }, 
  {
   "hits": 13, 
   "name": "framingham, ma"
  }, 
  {
   "hits": 13, 
   "name": "urbana, il"
  }, 
  {
   "hits": 13, 
   "name": "hollywood, fl"
  }, 
  {
   "hits": 13, 
   "name": "manchester, nh"
  }, 
  {
   "hits": 13, 
   "name": "savannah, ga"
  }, 
  {
   "hits": 13, 
   "name": "encinitas, ca"
  }, 
  {
   "hits": 13, 
   "name": "billings, mt"
  }, 
  {
   "hits": 13, 
   "name": "davis, ca"
  }, 
  {
   "hits": 13, 
   "name": "sammamish, wa"
  }, 
  {
   "hits": 13, 
   "name": "norman, ok"
  }, 
  {
   "hits": 13, 
   "name": "northampton, ma"
  }, 
  {
   "hits": 13, 
   "name": "las cruces, nm"
  }, 
  {
   "hits": 13, 
   "name": "lake worth, fl"
  }, 
  {
   "hits": 13, 
   "name": "burbank, ca"
  }, 
  {
   "hits": 13, 
   "name": "louisville, co"
  }, 
  {
   "hits": 12, 
   "name": "east lansing, mi"
  }, 
  {
   "hits": 12, 
   "name": "redondo beach, ca"
  }, 
  {
   "hits": 12, 
   "name": "sandy, ut"
  }, 
  {
   "hits": 12, 
   "name": "ventura, ca"
  }, 
  {
   "hits": 12, 
   "name": "sioux falls, sd"
  }, 
  {
   "hits": 12, 
   "name": "traverse city, mi"
  }, 
  {
   "hits": 12, 
   "name": "cheyenne, wy"
  }, 
  {
   "hits": 12, 
   "name": "renton, wa"
  }, 
  {
   "hits": 12, 
   "name": "springfield, il"
  }, 
  {
   "hits": 12, 
   "name": "palatine, il"
  }, 
  {
   "hits": 12, 
   "name": "kent, wa"
  }, 
  {
   "hits": 12, 
   "name": "belmont, ca"
  }, 
  {
   "hits": 12, 
   "name": "longmont, co"
  }, 
  {
   "hits": 12, 
   "name": "stockton, ca"
  }, 
  {
   "hits": 12, 
   "name": "akron, oh"
  }, 
  {
   "hits": 12, 
   "name": "takoma park, md"
  }, 
  {
   "hits": 12, 
   "name": "sausalito, ca"
  }, 
  {
   "hits": 12, 
   "name": "everett, wa"
  }, 
  {
   "hits": 12, 
   "name": "amherst, ma"
  }, 
  {
   "hits": 12, 
   "name": "alpharetta, ga"
  }, 
  {
   "hits": 12, 
   "name": "syracuse, ny"
  }, 
  {
   "hits": 12, 
   "name": "woodland hills, ca"
  }, 
  {
   "hits": 12, 
   "name": "burlington, vt"
  }, 
  {
   "hits": 12, 
   "name": "milpitas, ca"
  }, 
  {
   "hits": 12, 
   "name": "forest hills, ny"
  }, 
  {
   "hits": 12, 
   "name": "harrisburg, pa"
  }, 
  {
   "hits": 12, 
   "name": "fort myers, fl"
  }, 
  {
   "hits": 12, 
   "name": "manassas, va"
  }, 
  {
   "hits": 12, 
   "name": "corona, ca"
  }, 
  {
   "hits": 12, 
   "name": "cedar park, tx"
  }, 
  {
   "hits": 12, 
   "name": "duluth, mn"
  }, 
  {
   "hits": 12, 
   "name": "torrance, ca"
  }, 
  {
   "hits": 12, 
   "name": "sebastopol, ca"
  }, 
  {
   "hits": 11, 
   "name": "oceanside, ca"
  }, 
  {
   "hits": 11, 
   "name": "flagstaff, az"
  }, 
  {
   "hits": 11, 
   "name": "lewisville, tx"
  }, 
  {
   "hits": 11, 
   "name": "daly city, ca"
  }, 
  {
   "hits": 11, 
   "name": "camarillo, ca"
  }, 
  {
   "hits": 11, 
   "name": "skokie, il"
  }, 
  {
   "hits": 11, 
   "name": "tuscaloosa, al"
  }, 
  {
   "hits": 11, 
   "name": "carlsbad, ca"
  }, 
  {
   "hits": 11, 
   "name": "roswell, ga"
  }, 
  {
   "hits": 11, 
   "name": "santa ana, ca"
  }, 
  {
   "hits": 11, 
   "name": "roseville, ca"
  }, 
  {
   "hits": 11, 
   "name": "bethlehem, pa"
  }, 
  {
   "hits": 11, 
   "name": "modesto, ca"
  }, 
  {
   "hits": 11, 
   "name": "medford, or"
  }, 
  {
   "hits": 11, 
   "name": "malden, ma"
  }, 
  {
   "hits": 11, 
   "name": "centreville, va"
  }, 
  {
   "hits": 11, 
   "name": "napa, ca"
  }, 
  {
   "hits": 11, 
   "name": "petaluma, ca"
  }, 
  {
   "hits": 11, 
   "name": "ashland, or"
  }, 
  {
   "hits": 11, 
   "name": "towson, md"
  }, 
  {
   "hits": 11, 
   "name": "media, pa"
  }, 
  {
   "hits": 11, 
   "name": "long island city, ny"
  }, 
  {
   "hits": 11, 
   "name": "marina del rey, ca"
  }, 
  {
   "hits": 11, 
   "name": "bloomington, il"
  }, 
  {
   "hits": 11, 
   "name": "union city, ca"
  }, 
  {
   "hits": 11, 
   "name": "beverly, ma"
  }, 
  {
   "hits": 11, 
   "name": "el cerrito, ca"
  }, 
  {
   "hits": 11, 
   "name": "lafayette, co"
  }, 
  {
   "hits": 11, 
   "name": "detroit, mi"
  }, 
  {
   "hits": 11, 
   "name": "carrboro, nc"
  }, 
  {
   "hits": 11, 
   "name": "issaquah, wa"
  }, 
  {
   "hits": 11, 
   "name": "chula vista, ca"
  }, 
  {
   "hits": 11, 
   "name": "cedar rapids, ia"
  }, 
  {
   "hits": 10, 
   "name": "burlingame, ca"
  }, 
  {
   "hits": 10, 
   "name": "w hartford, ct"
  }, 
  {
   "hits": 10, 
   "name": "poway, ca"
  }, 
  {
   "hits": 10, 
   "name": "norristown, pa"
  }, 
  {
   "hits": 10, 
   "name": "west lafayette, in"
  }, 
  {
   "hits": 10, 
   "name": "arlington heights, il"
  }, 
  {
   "hits": 10, 
   "name": "fredericksburg, va"
  }, 
  {
   "hits": 10, 
   "name": "leesburg, va"
  }, 
  {
   "hits": 10, 
   "name": "appleton, wi"
  }, 
  {
   "hits": 10, 
   "name": "san carlos, ca"
  }, 
  {
   "hits": 10, 
   "name": "morrisville, nc"
  }, 
  {
   "hits": 10, 
   "name": "annapolis, md"
  }, 
  {
   "hits": 10, 
   "name": "highland park, il"
  }, 
  {
   "hits": 10, 
   "name": "campbell, ca"
  }, 
  {
   "hits": 10, 
   "name": "provo, ut"
  }, 
  {
   "hits": 10, 
   "name": "san luis obispo, ca"
  }, 
  {
   "hits": 10, 
   "name": "fairfield, ct"
  }, 
  {
   "hits": 10, 
   "name": "playa del rey, ca"
  }, 
  {
   "hits": 10, 
   "name": "studio city, ca"
  }, 
  {
   "hits": 10, 
   "name": "des moines, ia"
  }, 
  {
   "hits": 10, 
   "name": "palm springs, ca"
  }, 
  {
   "hits": 10, 
   "name": "northridge, ca"
  }, 
  {
   "hits": 10, 
   "name": "greenville, sc"
  }, 
  {
   "hits": 10, 
   "name": "pflugerville, tx"
  }, 
  {
   "hits": 10, 
   "name": "eureka, ca"
  }, 
  {
   "hits": 10, 
   "name": "laurel, md"
  }, 
  {
   "hits": 10, 
   "name": "orem, ut"
  }, 
  {
   "hits": 10, 
   "name": "culver city, ca"
  }, 
  {
   "hits": 10, 
   "name": "irving, tx"
  }, 
  {
   "hits": 10, 
   "name": "van nuys, ca"
  }, 
  {
   "hits": 10, 
   "name": "lafayette, in"
  }, 
  {
   "hits": 10, 
   "name": "west chester, pa"
  }, 
  {
   "hits": 10, 
   "name": "prescott, az"
  }, 
  {
   "hits": 10, 
   "name": "college station, tx"
  }, 
  {
   "hits": 10, 
   "name": "allen, tx"
  }, 
  {
   "hits": 10, 
   "name": "richmond, ca"
  }, 
  {
   "hits": 10, 
   "name": "golden, co"
  }, 
  {
   "hits": 10, 
   "name": "warren, mi"
  }, 
  {
   "hits": 10, 
   "name": "pullman, wa"
  }, 
  {
   "hits": 10, 
   "name": "dublin, ca"
  }, 
  {
   "hits": 9, 
   "name": "la crescenta, ca"
  }, 
  {
   "hits": 9, 
   "name": "lawrenceville, ga"
  }, 
  {
   "hits": 9, 
   "name": "west hollywood, ca"
  }, 
  {
   "hits": 9, 
   "name": "downingtown, pa"
  }, 
  {
   "hits": 9, 
   "name": "garland, tx"
  }, 
  {
   "hits": 9, 
   "name": "citrus heights, ca"
  }, 
  {
   "hits": 9, 
   "name": "gresham, or"
  }, 
  {
   "hits": 9, 
   "name": "royal oak, mi"
  }, 
  {
   "hits": 9, 
   "name": "rio rancho, nm"
  }, 
  {
   "hits": 9, 
   "name": "bozeman, mt"
  }, 
  {
   "hits": 9, 
   "name": "altadena, ca"
  }, 
  {
   "hits": 9, 
   "name": "san leandro, ca"
  }, 
  {
   "hits": 9, 
   "name": "hyattsville, md"
  }, 
  {
   "hits": 9, 
   "name": "winter park, fl"
  }, 
  {
   "hits": 9, 
   "name": "aliso viejo, ca"
  }, 
  {
   "hits": 9, 
   "name": "sterling, va"
  }, 
  {
   "hits": 9, 
   "name": "chesapeake, va"
  }, 
  {
   "hits": 9, 
   "name": "reading, pa"
  }, 
  {
   "hits": 9, 
   "name": "castle rock, co"
  }, 
  {
   "hits": 9, 
   "name": ", mi"
  }, 
  {
   "hits": 9, 
   "name": "troy, mi"
  }, 
  {
   "hits": 9, 
   "name": "pleasanton, ca"
  }, 
  {
   "hits": 9, 
   "name": "bremerton, wa"
  }, 
  {
   "hits": 9, 
   "name": "arcadia, ca"
  }, 
  {
   "hits": 9, 
   "name": "logan, ut"
  }, 
  {
   "hits": 9, 
   "name": "lutherville timonium, md"
  }, 
  {
   "hits": 9, 
   "name": "fairbanks, ak"
  }, 
  {
   "hits": 9, 
   "name": "springfield, mo"
  }, 
  {
   "hits": 9, 
   "name": "edmonds, wa"
  }, 
  {
   "hits": 9, 
   "name": "metairie, la"
  }, 
  {
   "hits": 9, 
   "name": "apex, nc"
  }, 
  {
   "hits": 9, 
   "name": "sunnyside, ny"
  }, 
  {
   "hits": 9, 
   "name": "goleta, ca"
  }, 
  {
   "hits": 9, 
   "name": "mill valley, ca"
  }, 
  {
   "hits": 9, 
   "name": "alhambra, ca"
  }, 
  {
   "hits": 9, 
   "name": "woodinville, wa"
  }, 
  {
   "hits": 9, 
   "name": "lakeland, fl"
  }, 
  {
   "hits": 9, 
   "name": "lancaster, pa"
  }, 
  {
   "hits": 9, 
   "name": "yakima, wa"
  }, 
  {
   "hits": 9, 
   "name": "san bruno, ca"
  }, 
  {
   "hits": 9, 
   "name": "danville, ca"
  }, 
  {
   "hits": 9, 
   "name": "great falls, va"
  }, 
  {
   "hits": 9, 
   "name": "jamaica, ny"
  }, 
  {
   "hits": 9, 
   "name": "ballwin, mo"
  }, 
  {
   "hits": 9, 
   "name": "bridgewater, nj"
  }, 
  {
   "hits": 9, 
   "name": "redlands, ca"
  }, 
  {
   "hits": 9, 
   "name": "glendale, az"
  }, 
  {
   "hits": 9, 
   "name": "arvada, co"
  }, 
  {
   "hits": 9, 
   "name": "concord, ca"
  }, 
  {
   "hits": 8, 
   "name": "westford, ma"
  }, 
  {
   "hits": 8, 
   "name": "kalamazoo, mi"
  }, 
  {
   "hits": 8, 
   "name": "el cajon, ca"
  }, 
  {
   "hits": 8, 
   "name": "lake orion, mi"
  }, 
  {
   "hits": 8, 
   "name": "topeka, ks"
  }, 
  {
   "hits": 8, 
   "name": "lake oswego, or"
  }, 
  {
   "hits": 8, 
   "name": "salem, ma"
  }, 
  {
   "hits": 8, 
   "name": "glenview, il"
  }, 
  {
   "hits": 8, 
   "name": "san marcos, tx"
  }, 
  {
   "hits": 8, 
   "name": "des plaines, il"
  }, 
  {
   "hits": 8, 
   "name": "sugar land, tx"
  }, 
  {
   "hits": 8, 
   "name": "poughkeepsie, ny"
  }, 
  {
   "hits": 8, 
   "name": "round rock, tx"
  }, 
  {
   "hits": 8, 
   "name": "lakewood, ca"
  }, 
  {
   "hits": 8, 
   "name": "college park, md"
  }, 
  {
   "hits": 8, 
   "name": "humble, tx"
  }, 
  {
   "hits": 8, 
   "name": "lees summit, mo"
  }, 
  {
   "hits": 8, 
   "name": "marysville, wa"
  }, 
  {
   "hits": 8, 
   "name": "ambler, pa"
  }, 
  {
   "hits": 8, 
   "name": "englewood, co"
  }, 
  {
   "hits": 8, 
   "name": "monterey, ca"
  }, 
  {
   "hits": 8, 
   "name": "mentor, oh"
  }, 
  {
   "hits": 8, 
   "name": "dekalb, il"
  }, 
  {
   "hits": 8, 
   "name": "pacifica, ca"
  }, 
  {
   "hits": 8, 
   "name": "green bay, wi"
  }, 
  {
   "hits": 8, 
   "name": "jackson heights, ny"
  }, 
  {
   "hits": 8, 
   "name": "york, pa"
  }, 
  {
   "hits": 8, 
   "name": "ojai, ca"
  }, 
  {
   "hits": 8, 
   "name": "ogden, ut"
  }, 
  {
   "hits": 8, 
   "name": "montclair, nj"
  }, 
  {
   "hits": 8, 
   "name": "athens, oh"
  }, 
  {
   "hits": 8, 
   "name": "morgantown, wv"
  }, 
  {
   "hits": 8, 
   "name": "vista, ca"
  }, 
  {
   "hits": 8, 
   "name": "palmdale, ca"
  }, 
  {
   "hits": 8, 
   "name": "lubbock, tx"
  }, 
  {
   "hits": 8, 
   "name": "bolingbrook, il"
  }, 
  {
   "hits": 8, 
   "name": "jackson, ms"
  }, 
  {
   "hits": 8, 
   "name": "erie, pa"
  }, 
  {
   "hits": 8, 
   "name": "lansing, mi"
  }, 
  {
   "hits": 8, 
   "name": "walnut, ca"
  }, 
  {
   "hits": 8, 
   "name": "easton, pa"
  }, 
  {
   "hits": 8, 
   "name": "holland, mi"
  }, 
  {
   "hits": 8, 
   "name": "chevy chase, md"
  }, 
  {
   "hits": 8, 
   "name": "clarksville, tn"
  }, 
  {
   "hits": 8, 
   "name": "flushing, ny"
  }, 
  {
   "hits": 8, 
   "name": "la mesa, ca"
  }, 
  {
   "hits": 8, 
   "name": ", tx"
  }, 
  {
   "hits": 8, 
   "name": "johnson city, tn"
  }, 
  {
   "hits": 8, 
   "name": "corpus christi, tx"
  }, 
  {
   "hits": 8, 
   "name": "pleasant grove, ut"
  }, 
  {
   "hits": 8, 
   "name": "kingston, ny"
  }, 
  {
   "hits": 8, 
   "name": "concord, ma"
  }, 
  {
   "hits": 8, 
   "name": "conroe, tx"
  }, 
  {
   "hits": 8, 
   "name": "schaumburg, il"
  }, 
  {
   "hits": 8, 
   "name": "fullerton, ca"
  }, 
  {
   "hits": 8, 
   "name": "parker, co"
  }, 
  {
   "hits": 8, 
   "name": "laguna beach, ca"
  }, 
  {
   "hits": 7, 
   "name": "hilliard, oh"
  }, 
  {
   "hits": 7, 
   "name": "williamsburg, va"
  }, 
  {
   "hits": 7, 
   "name": "saratoga, ca"
  }, 
  {
   "hits": 7, 
   "name": "barrington, il"
  }, 
  {
   "hits": 7, 
   "name": "simi valley, ca"
  }, 
  {
   "hits": 7, 
   "name": "claremont, ca"
  }, 
  {
   "hits": 7, 
   "name": "concord, nh"
  }, 
  {
   "hits": 7, 
   "name": "mooresville, nc"
  }, 
  {
   "hits": 7, 
   "name": "hampton, va"
  }, 
  {
   "hits": 7, 
   "name": "federal way, wa"
  }, 
  {
   "hits": 7, 
   "name": "troy, ny"
  }, 
  {
   "hits": 7, 
   "name": "canton, oh"
  }, 
  {
   "hits": 7, 
   "name": "roslindale, ma"
  }, 
  {
   "hits": 7, 
   "name": "sterling heights, mi"
  }, 
  {
   "hits": 7, 
   "name": "round lake, il"
  }, 
  {
   "hits": 7, 
   "name": "san pedro, ca"
  }, 
  {
   "hits": 7, 
   "name": "bellevue, ne"
  }, 
  {
   "hits": 7, 
   "name": "woodbridge, va"
  }, 
  {
   "hits": 7, 
   "name": "canton, mi"
  }, 
  {
   "hits": 7, 
   "name": "murfreesboro, tn"
  }, 
  {
   "hits": 7, 
   "name": "cypress, tx"
  }, 
  {
   "hits": 7, 
   "name": "port townsend, wa"
  }, 
  {
   "hits": 7, 
   "name": "leander, tx"
  }, 
  {
   "hits": 7, 
   "name": "lowell, ma"
  }, 
  {
   "hits": 7, 
   "name": "keller, tx"
  }, 
  {
   "hits": 7, 
   "name": "carmel, in"
  }, 
  {
   "hits": 7, 
   "name": "san clemente, ca"
  }, 
  {
   "hits": 7, 
   "name": "castro valley, ca"
  }, 
  {
   "hits": 7, 
   "name": "chestnut hill, ma"
  }, 
  {
   "hits": 7, 
   "name": "lansdale, pa"
  }, 
  {
   "hits": 7, 
   "name": "chantilly, va"
  }, 
  {
   "hits": 7, 
   "name": "gilbert, az"
  }, 
  {
   "hits": 7, 
   "name": "saint charles, mo"
  }, 
  {
   "hits": 7, 
   "name": "springfield, ma"
  }, 
  {
   "hits": 7, 
   "name": "juneau, ak"
  }, 
  {
   "hits": 7, 
   "name": "independence, mo"
  }, 
  {
   "hits": 7, 
   "name": "beachwood, oh"
  }, 
  {
   "hits": 7, 
   "name": "bainbridge island, wa"
  }, 
  {
   "hits": 7, 
   "name": "fountain valley, ca"
  }, 
  {
   "hits": 7, 
   "name": "bedford, ma"
  }, 
  {
   "hits": 7, 
   "name": "white plains, ny"
  }, 
  {
   "hits": 7, 
   "name": "chatsworth, ca"
  }, 
  {
   "hits": 7, 
   "name": "bangor, me"
  }, 
  {
   "hits": 7, 
   "name": "holly springs, nc"
  }, 
  {
   "hits": 7, 
   "name": "reseda, ca"
  }, 
  {
   "hits": 7, 
   "name": "bend, or"
  }, 
  {
   "hits": 7, 
   "name": "greenwich, ct"
  }, 
  {
   "hits": 7, 
   "name": "charleston, wv"
  }, 
  {
   "hits": 7, 
   "name": "stamford, ct"
  }, 
  {
   "hits": 7, 
   "name": "summerville, sc"
  }, 
  {
   "hits": 7, 
   "name": "harrisonburg, va"
  }, 
  {
   "hits": 7, 
   "name": "woodside, ny"
  }, 
  {
   "hits": 7, 
   "name": "yonkers, ny"
  }, 
  {
   "hits": 7, 
   "name": "stillwater, ok"
  }, 
  {
   "hits": 7, 
   "name": "maplewood, nj"
  }, 
  {
   "hits": 7, 
   "name": "cherry hill, nj"
  }, 
  {
   "hits": 7, 
   "name": "winnetka, ca"
  }, 
  {
   "hits": 7, 
   "name": "wheaton, il"
  }, 
  {
   "hits": 7, 
   "name": "rancho cucamonga, ca"
  }, 
  {
   "hits": 7, 
   "name": "elkins park, pa"
  }, 
  {
   "hits": 7, 
   "name": "yorba linda, ca"
  }, 
  {
   "hits": 7, 
   "name": "naples, fl"
  }, 
  {
   "hits": 7, 
   "name": "grapevine, tx"
  }, 
  {
   "hits": 7, 
   "name": "haverhill, ma"
  }, 
  {
   "hits": 7, 
   "name": "palm bay, fl"
  }, 
  {
   "hits": 7, 
   "name": "salinas, ca"
  }, 
  {
   "hits": 7, 
   "name": "oxnard, ca"
  }, 
  {
   "hits": 6, 
   "name": "melrose, ma"
  }, 
  {
   "hits": 6, 
   "name": "san anselmo, ca"
  }, 
  {
   "hits": 6, 
   "name": "moorhead, mn"
  }, 
  {
   "hits": 6, 
   "name": "union city, nj"
  }, 
  {
   "hits": 6, 
   "name": "deerfield, il"
  }, 
  {
   "hits": 6, 
   "name": ", ma"
  }, 
  {
   "hits": 6, 
   "name": "vallejo, ca"
  }, 
  {
   "hits": 6, 
   "name": "odenton, md"
  }, 
  {
   "hits": 6, 
   "name": "glen head, ny"
  }, 
  {
   "hits": 6, 
   "name": "brisbane, ca"
  }, 
  {
   "hits": 6, 
   "name": "cardiff by the sea, ca"
  }, 
  {
   "hits": 6, 
   "name": "north easton, ma"
  }, 
  {
   "hits": 6, 
   "name": "andover, ma"
  }, 
  {
   "hits": 6, 
   "name": "annandale, va"
  }, 
  {
   "hits": 6, 
   "name": "milton, fl"
  }, 
  {
   "hits": 6, 
   "name": "chesterfield, mo"
  }, 
  {
   "hits": 6, 
   "name": "northbrook, il"
  }, 
  {
   "hits": 6, 
   "name": "germantown, md"
  }, 
  {
   "hits": 6, 
   "name": "cape coral, fl"
  }, 
  {
   "hits": 6, 
   "name": "addison, tx"
  }, 
  {
   "hits": 6, 
   "name": "westminster, ca"
  }, 
  {
   "hits": 6, 
   "name": "woburn, ma"
  }, 
  {
   "hits": 6, 
   "name": "milford, oh"
  }, 
  {
   "hits": 6, 
   "name": "west linn, or"
  }, 
  {
   "hits": 6, 
   "name": "north richland hills, tx"
  }, 
  {
   "hits": 6, 
   "name": "canoga park, ca"
  }, 
  {
   "hits": 6, 
   "name": "binghamton, ny"
  }, 
  {
   "hits": 6, 
   "name": "norcross, ga"
  }, 
  {
   "hits": 6, 
   "name": "lynn, ma"
  }, 
  {
   "hits": 6, 
   "name": "peoria, il"
  }, 
  {
   "hits": 6, 
   "name": "livermore, ca"
  }, 
  {
   "hits": 6, 
   "name": "garden grove, ca"
  }, 
  {
   "hits": 6, 
   "name": "havertown, pa"
  }, 
  {
   "hits": 6, 
   "name": "laredo, tx"
  }, 
  {
   "hits": 6, 
   "name": "newtonville, ma"
  }, 
  {
   "hits": 6, 
   "name": "hartford, ct"
  }, 
  {
   "hits": 6, 
   "name": "eau claire, wi"
  }, 
  {
   "hits": 6, 
   "name": "bel air, md"
  }, 
  {
   "hits": 6, 
   "name": "tucker, ga"
  }, 
  {
   "hits": 6, 
   "name": "durango, co"
  }, 
  {
   "hits": 6, 
   "name": "utica, ny"
  }, 
  {
   "hits": 6, 
   "name": "springfield, oh"
  }, 
  {
   "hits": 6, 
   "name": "nevada city, ca"
  }, 
  {
   "hits": 6, 
   "name": "lisle, il"
  }, 
  {
   "hits": 6, 
   "name": "pittsburg, ca"
  }, 
  {
   "hits": 6, 
   "name": "swampscott, ma"
  }, 
  {
   "hits": 6, 
   "name": "ferndale, mi"
  }, 
  {
   "hits": 6, 
   "name": ", ny"
  }, 
  {
   "hits": 6, 
   "name": "antioch, ca"
  }, 
  {
   "hits": 6, 
   "name": "denton, tx"
  }, 
  {
   "hits": 6, 
   "name": "rocky river, oh"
  }, 
  {
   "hits": 6, 
   "name": "acton, ma"
  }, 
  {
   "hits": 6, 
   "name": "richmond, ky"
  }, 
  {
   "hits": 6, 
   "name": "melbourne, fl"
  }, 
  {
   "hits": 6, 
   "name": "mechanicsville, va"
  }, 
  {
   "hits": 6, 
   "name": "hialeah, fl"
  }, 
  {
   "hits": 6, 
   "name": "south san francisco, ca"
  }, 
  {
   "hits": 6, 
   "name": "downers grove, il"
  }, 
  {
   "hits": 6, 
   "name": "elmhurst, ny"
  }, 
  {
   "hits": 6, 
   "name": "potomac, md"
  }, 
  {
   "hits": 6, 
   "name": "mililani, hi"
  }, 
  {
   "hits": 6, 
   "name": "starkville, ms"
  }, 
  {
   "hits": 6, 
   "name": "fairfield, oh"
  }, 
  {
   "hits": 6, 
   "name": "elk grove, ca"
  }, 
  {
   "hits": 6, 
   "name": "la habra, ca"
  }, 
  {
   "hits": 6, 
   "name": "pasadena, md"
  }, 
  {
   "hits": 6, 
   "name": "wappingers falls, ny"
  }, 
  {
   "hits": 6, 
   "name": "sierra madre, ca"
  }, 
  {
   "hits": 6, 
   "name": "portage, mi"
  }, 
  {
   "hits": 6, 
   "name": "williamstown, ma"
  }, 
  {
   "hits": 6, 
   "name": "pittsford, ny"
  }, 
  {
   "hits": 6, 
   "name": "toms river, nj"
  }, 
  {
   "hits": 6, 
   "name": ", nj"
  }, 
  {
   "hits": 6, 
   "name": "largo, fl"
  }, 
  {
   "hits": 6, 
   "name": "diamond bar, ca"
  }, 
  {
   "hits": 6, 
   "name": "felton, ca"
  }, 
  {
   "hits": 6, 
   "name": "vacaville, ca"
  }, 
  {
   "hits": 6, 
   "name": "rockford, il"
  }, 
  {
   "hits": 6, 
   "name": "murrieta, ca"
  }, 
  {
   "hits": 6, 
   "name": "greenwood, in"
  }, 
  {
   "hits": 6, 
   "name": "puyallup, wa"
  }, 
  {
   "hits": 6, 
   "name": "kenosha, wi"
  }, 
  {
   "hits": 6, 
   "name": "ontario, ca"
  }, 
  {
   "hits": 6, 
   "name": "farmington, nm"
  }, 
  {
   "hits": 6, 
   "name": "newark, nj"
  }, 
  {
   "hits": 6, 
   "name": "midlothian, va"
  }, 
  {
   "hits": 6, 
   "name": "lafayette, la"
  }, 
  {
   "hits": 6, 
   "name": "winchester, va"
  }, 
  {
   "hits": 6, 
   "name": "princeton junction, nj"
  }, 
  {
   "hits": 6, 
   "name": "league city, tx"
  }, 
  {
   "hits": 6, 
   "name": "fairport, ny"
  }, 
  {
   "hits": 6, 
   "name": "sonoma, ca"
  }, 
  {
   "hits": 6, 
   "name": "livonia, mi"
  }, 
  {
   "hits": 6, 
   "name": "longwood, fl"
  }, 
  {
   "hits": 6, 
   "name": "hermosa beach, ca"
  }, 
  {
   "hits": 6, 
   "name": "delray beach, fl"
  }, 
  {
   "hits": 6, 
   "name": "whittier, ca"
  }, 
  {
   "hits": 6, 
   "name": "wilmette, il"
  }, 
  {
   "hits": 6, 
   "name": "watsonville, ca"
  }, 
  {
   "hits": 6, 
   "name": "norwalk, ct"
  }, 
  {
   "hits": 6, 
   "name": "north bend, wa"
  }, 
  {
   "hits": 6, 
   "name": "stone mountain, ga"
  }, 
  {
   "hits": 6, 
   "name": "amarillo, tx"
  }, 
  {
   "hits": 6, 
   "name": "martinez, ca"
  }, 
  {
   "hits": 6, 
   "name": "winchester, ma"
  }, 
  {
   "hits": 6, 
   "name": "westerville, oh"
  }, 
  {
   "hits": 6, 
   "name": "ben lomond, ca"
  }, 
  {
   "hits": 6, 
   "name": "brentwood, tn"
  }, 
  {
   "hits": 6, 
   "name": "altamonte springs, fl"
  }, 
  {
   "hits": 6, 
   "name": "bellflower, ca"
  }, 
  {
   "hits": 6, 
   "name": "newport news, va"
  }, 
  {
   "hits": 6, 
   "name": "charlestown, ma"
  }, 
  {
   "hits": 6, 
   "name": "mercer island, wa"
  }, 
  {
   "hits": 5, 
   "name": "owings mills, md"
  }, 
  {
   "hits": 5, 
   "name": "manhattan, ks"
  }, 
  {
   "hits": 5, 
   "name": "rancho palos verdes, ca"
  }, 
  {
   "hits": 5, 
   "name": "bradenton, fl"
  }, 
  {
   "hits": 5, 
   "name": "norwood, ma"
  }, 
  {
   "hits": 5, 
   "name": "palos verdes peninsula, ca"
  }, 
  {
   "hits": 5, 
   "name": "harvard, ma"
  }, 
  {
   "hits": 5, 
   "name": "frisco, tx"
  }, 
  {
   "hits": 5, 
   "name": "rapid city, sd"
  }, 
  {
   "hits": 5, 
   "name": "boynton beach, fl"
  }, 
  {
   "hits": 5, 
   "name": "coppell, tx"
  }, 
  {
   "hits": 5, 
   "name": "brick, nj"
  }, 
  {
   "hits": 5, 
   "name": "montpelier, vt"
  }, 
  {
   "hits": 5, 
   "name": "winthrop, ma"
  }, 
  {
   "hits": 5, 
   "name": "hopkins, mn"
  }, 
  {
   "hits": 5, 
   "name": "winnetka, il"
  }, 
  {
   "hits": 5, 
   "name": "san bernardino, ca"
  }, 
  {
   "hits": 5, 
   "name": "hopewell junction, ny"
  }, 
  {
   "hits": 5, 
   "name": "passaic, nj"
  }, 
  {
   "hits": 5, 
   "name": "snohomish, wa"
  }, 
  {
   "hits": 5, 
   "name": "kenmore, wa"
  }, 
  {
   "hits": 5, 
   "name": "noblesville, in"
  }, 
  {
   "hits": 5, 
   "name": "boulder creek, ca"
  }, 
  {
   "hits": 5, 
   "name": "warwick, ri"
  }, 
  {
   "hits": 5, 
   "name": "valley village, ca"
  }, 
  {
   "hits": 5, 
   "name": "everett, ma"
  }, 
  {
   "hits": 5, 
   "name": "rancho cordova, ca"
  }, 
  {
   "hits": 5, 
   "name": ", wa"
  }, 
  {
   "hits": 5, 
   "name": "storrs mansfield, ct"
  }, 
  {
   "hits": 5, 
   "name": "laguna niguel, ca"
  }, 
  {
   "hits": 5, 
   "name": "lake forest, il"
  }, 
  {
   "hits": 5, 
   "name": "oldsmar, fl"
  }, 
  {
   "hits": 5, 
   "name": "bossier city, la"
  }, 
  {
   "hits": 5, 
   "name": "pasadena, tx"
  }, 
  {
   "hits": 5, 
   "name": "burnsville, mn"
  }, 
  {
   "hits": 5, 
   "name": "muncie, in"
  }, 
  {
   "hits": 5, 
   "name": "rohnert park, ca"
  }, 
  {
   "hits": 5, 
   "name": "keene, nh"
  }, 
  {
   "hits": 5, 
   "name": "holden, ma"
  }, 
  {
   "hits": 5, 
   "name": "desert hot springs, ca"
  }, 
  {
   "hits": 5, 
   "name": "malibu, ca"
  }, 
  {
   "hits": 5, 
   "name": "valencia, ca"
  }, 
  {
   "hits": 5, 
   "name": "vashon, wa"
  }, 
  {
   "hits": 5, 
   "name": "layton, ut"
  }, 
  {
   "hits": 5, 
   "name": "vineland, nj"
  }, 
  {
   "hits": 5, 
   "name": "bloomfield, nj"
  }, 
  {
   "hits": 5, 
   "name": "grand junction, co"
  }, 
  {
   "hits": 5, 
   "name": "marshfield, ma"
  }, 
  {
   "hits": 5, 
   "name": "tyler, tx"
  }, 
  {
   "hits": 5, 
   "name": "vienna, va"
  }, 
  {
   "hits": 5, 
   "name": "kissimmee, fl"
  }, 
  {
   "hits": 5, 
   "name": "evansville, in"
  }, 
  {
   "hits": 5, 
   "name": "lombard, il"
  }, 
  {
   "hits": 5, 
   "name": "morrisville, pa"
  }, 
  {
   "hits": 5, 
   "name": "ridgewood, nj"
  }, 
  {
   "hits": 5, 
   "name": "signal mountain, tn"
  }, 
  {
   "hits": 5, 
   "name": "wake forest, nc"
  }, 
  {
   "hits": 5, 
   "name": "folsom, ca"
  }, 
  {
   "hits": 5, 
   "name": "warner robins, ga"
  }, 
  {
   "hits": 5, 
   "name": "loveland, co"
  }, 
  {
   "hits": 5, 
   "name": "aptos, ca"
  }, 
  {
   "hits": 5, 
   "name": "easthampton, ma"
  }, 
  {
   "hits": 5, 
   "name": "pomona, ca"
  }, 
  {
   "hits": 5, 
   "name": "waukesha, wi"
  }, 
  {
   "hits": 5, 
   "name": "waterford, mi"
  }, 
  {
   "hits": 5, 
   "name": "hot springs national park, ar"
  }, 
  {
   "hits": 5, 
   "name": "belleville, mi"
  }, 
  {
   "hits": 5, 
   "name": "jupiter, fl"
  }, 
  {
   "hits": 5, 
   "name": "the colony, tx"
  }, 
  {
   "hits": 5, 
   "name": "flower mound, tx"
  }, 
  {
   "hits": 5, 
   "name": "maynard, ma"
  }, 
  {
   "hits": 5, 
   "name": "sparta, nj"
  }, 
  {
   "hits": 5, 
   "name": "lake zurich, il"
  }, 
  {
   "hits": 5, 
   "name": "highland park, nj"
  }, 
  {
   "hits": 5, 
   "name": "westfield, nj"
  }, 
  {
   "hits": 5, 
   "name": "friendswood, tx"
  }, 
  {
   "hits": 5, 
   "name": "north palm beach, fl"
  }, 
  {
   "hits": 5, 
   "name": "livingston, nj"
  }, 
  {
   "hits": 5, 
   "name": "mchenry, il"
  }, 
  {
   "hits": 5, 
   "name": "deland, fl"
  }, 
  {
   "hits": 5, 
   "name": "kansas city, ks"
  }, 
  {
   "hits": 5, 
   "name": "great barrington, ma"
  }, 
  {
   "hits": 5, 
   "name": "pacific palisades, ca"
  }, 
  {
   "hits": 5, 
   "name": "anderson, in"
  }, 
  {
   "hits": 5, 
   "name": "novi, mi"
  }, 
  {
   "hits": 5, 
   "name": "pawtucket, ri"
  }, 
  {
   "hits": 5, 
   "name": "saint charles, il"
  }, 
  {
   "hits": 5, 
   "name": "clinton township, mi"
  }, 
  {
   "hits": 5, 
   "name": "baytown, tx"
  }, 
  {
   "hits": 5, 
   "name": "hicksville, ny"
  }, 
  {
   "hits": 5, 
   "name": "galveston, tx"
  }, 
  {
   "hits": 5, 
   "name": "carbondale, il"
  }, 
  {
   "hits": 5, 
   "name": "tonawanda, ny"
  }, 
  {
   "hits": 5, 
   "name": "seal beach, ca"
  }, 
  {
   "hits": 5, 
   "name": "brunswick, ga"
  }, 
  {
   "hits": 5, 
   "name": "clarkston, mi"
  }, 
  {
   "hits": 5, 
   "name": "los alamos, nm"
  }, 
  {
   "hits": 5, 
   "name": "high point, nc"
  }, 
  {
   "hits": 5, 
   "name": "south burlington, vt"
  }, 
  {
   "hits": 5, 
   "name": "san juan, pr"
  }, 
  {
   "hits": 5, 
   "name": "aiea, hi"
  }, 
  {
   "hits": 5, 
   "name": "newton, ma"
  }, 
  {
   "hits": 5, 
   "name": "hopkinton, ma"
  }, 
  {
   "hits": 5, 
   "name": "groton, ma"
  }, 
  {
   "hits": 5, 
   "name": "corte madera, ca"
  }, 
  {
   "hits": 5, 
   "name": "nicholasville, ky"
  }, 
  {
   "hits": 5, 
   "name": "abilene, tx"
  }, 
  {
   "hits": 5, 
   "name": "cumming, ga"
  }, 
  {
   "hits": 5, 
   "name": "encino, ca"
  }, 
  {
   "hits": 5, 
   "name": "marlborough, ma"
  }, 
  {
   "hits": 5, 
   "name": "acworth, ga"
  }, 
  {
   "hits": 5, 
   "name": "glenside, pa"
  }, 
  {
   "hits": 5, 
   "name": "east elmhurst, ny"
  }, 
  {
   "hits": 5, 
   "name": "fort pierce, fl"
  }, 
  {
   "hits": 5, 
   "name": "tomball, tx"
  }, 
  {
   "hits": 5, 
   "name": "tehachapi, ca"
  }, 
  {
   "hits": 5, 
   "name": "huntington, wv"
  }, 
  {
   "hits": 5, 
   "name": "lincoln, ma"
  }, 
  {
   "hits": 5, 
   "name": "mesquite, tx"
  }, 
  {
   "hits": 5, 
   "name": "mobile, al"
  }, 
  {
   "hits": 5, 
   "name": "rome, ny"
  }, 
  {
   "hits": 5, 
   "name": "needham, ma"
  }, 
  {
   "hits": 5, 
   "name": "west newton, ma"
  }, 
  {
   "hits": 5, 
   "name": "spartanburg, sc"
  }, 
  {
   "hits": 5, 
   "name": "broken arrow, ok"
  }, 
  {
   "hits": 5, 
   "name": ", fl"
  }, 
  {
   "hits": 5, 
   "name": "dearborn, mi"
  }, 
  {
   "hits": 5, 
   "name": "inglewood, ca"
  }, 
  {
   "hits": 5, 
   "name": "brandon, fl"
  }, 
  {
   "hits": 5, 
   "name": "st. louis, mo"
  }, 
  {
   "hits": 5, 
   "name": "bentonville, ar"
  }, 
  {
   "hits": 5, 
   "name": "san gabriel, ca"
  }, 
  {
   "hits": 5, 
   "name": "thousand oaks, ca"
  }, 
  {
   "hits": 5, 
   "name": "blacklick, oh"
  }, 
  {
   "hits": 5, 
   "name": "westborough, ma"
  }, 
  {
   "hits": 5, 
   "name": "conway, ar"
  }, 
  {
   "hits": 5, 
   "name": "santee, ca"
  }, 
  {
   "hits": 5, 
   "name": "aurora, il"
  }, 
  {
   "hits": 5, 
   "name": "boone, nc"
  }, 
  {
   "hits": 5, 
   "name": "mount vernon, il"
  }, 
  {
   "hits": 5, 
   "name": "addison, il"
  }, 
  {
   "hits": 5, 
   "name": "west bloomfield, mi"
  }, 
  {
   "hits": 5, 
   "name": "wellesley hills, ma"
  }, 
  {
   "hits": 4, 
   "name": "libertyville, il"
  }, 
  {
   "hits": 4, 
   "name": "orangevale, ca"
  }, 
  {
   "hits": 4, 
   "name": "carol stream, il"
  }, 
  {
   "hits": 4, 
   "name": "titusville, fl"
  }, 
  {
   "hits": 4, 
   "name": "southampton, pa"
  }, 
  {
   "hits": 4, 
   "name": "zionsville, in"
  }, 
  {
   "hits": 4, 
   "name": "granada hills, ca"
  }, 
  {
   "hits": 4, 
   "name": "marquette, mi"
  }, 
  {
   "hits": 4, 
   "name": "catonsville, md"
  }, 
  {
   "hits": 4, 
   "name": "youngstown, oh"
  }, 
  {
   "hits": 4, 
   "name": "audubon, nj"
  }, 
  {
   "hits": 4, 
   "name": "fairfield, ia"
  }, 
  {
   "hits": 4, 
   "name": "mason, oh"
  }, 
  {
   "hits": 4, 
   "name": "fairfax, ca"
  }, 
  {
   "hits": 4, 
   "name": "mount pleasant, sc"
  }, 
  {
   "hits": 4, 
   "name": "orleans, ma"
  }, 
  {
   "hits": 4, 
   "name": "elkridge, md"
  }, 
  {
   "hits": 4, 
   "name": "berkley, mi"
  }, 
  {
   "hits": 4, 
   "name": "new paltz, ny"
  }, 
  {
   "hits": 4, 
   "name": "scotts valley, ca"
  }, 
  {
   "hits": 4, 
   "name": "mundelein, il"
  }, 
  {
   "hits": 4, 
   "name": "mount prospect, il"
  }, 
  {
   "hits": 4, 
   "name": "philomath, or"
  }, 
  {
   "hits": 4, 
   "name": "russellville, ar"
  }, 
  {
   "hits": 4, 
   "name": "monrovia, ca"
  }, 
  {
   "hits": 4, 
   "name": "kula, hi"
  }, 
  {
   "hits": 4, 
   "name": "tarrytown, ny"
  }, 
  {
   "hits": 4, 
   "name": "saint augustine, fl"
  }, 
  {
   "hits": 4, 
   "name": "redford, mi"
  }, 
  {
   "hits": 4, 
   "name": "de pere, wi"
  }, 
  {
   "hits": 4, 
   "name": "pelham, ny"
  }, 
  {
   "hits": 4, 
   "name": "fairfax station, va"
  }, 
  {
   "hits": 4, 
   "name": "bowling green, oh"
  }, 
  {
   "hits": 4, 
   "name": "pleasant hill, ca"
  }, 
  {
   "hits": 4, 
   "name": "manhattan beach, ca"
  }, 
  {
   "hits": 4, 
   "name": "rogers, ar"
  }, 
  {
   "hits": 4, 
   "name": "marblehead, ma"
  }, 
  {
   "hits": 4, 
   "name": "croton on hudson, ny"
  }, 
  {
   "hits": 4, 
   "name": "north las vegas, nv"
  }, 
  {
   "hits": 4, 
   "name": "marlboro, nj"
  }, 
  {
   "hits": 4, 
   "name": "brownsville, tx"
  }, 
  {
   "hits": 4, 
   "name": "lake stevens, wa"
  }, 
  {
   "hits": 4, 
   "name": "midvale, ut"
  }, 
  {
   "hits": 4, 
   "name": "dacula, ga"
  }, 
  {
   "hits": 4, 
   "name": "massapequa park, ny"
  }, 
  {
   "hits": 4, 
   "name": "smyrna, ga"
  }, 
  {
   "hits": 4, 
   "name": "newport beach, ca"
  }, 
  {
   "hits": 4, 
   "name": "orinda, ca"
  }, 
  {
   "hits": 4, 
   "name": "hartland, wi"
  }, 
  {
   "hits": 4, 
   "name": "sequim, wa"
  }, 
  {
   "hits": 4, 
   "name": "lawton, ok"
  }, 
  {
   "hits": 4, 
   "name": "hemet, ca"
  }, 
  {
   "hits": 4, 
   "name": "waco, tx"
  }, 
  {
   "hits": 4, 
   "name": "columbus, ga"
  }, 
  {
   "hits": 4, 
   "name": "idaho falls, id"
  }, 
  {
   "hits": 4, 
   "name": "elmhurst, il"
  }, 
  {
   "hits": 4, 
   "name": "berlin, ma"
  }, 
  {
   "hits": 4, 
   "name": "ashland, ma"
  }, 
  {
   "hits": 4, 
   "name": "quincy, il"
  }, 
  {
   "hits": 4, 
   "name": "auburn hills, mi"
  }, 
  {
   "hits": 4, 
   "name": "san ramon, ca"
  }, 
  {
   "hits": 4, 
   "name": "cypress, ca"
  }, 
  {
   "hits": 4, 
   "name": "coeur d alene, id"
  }, 
  {
   "hits": 4, 
   "name": "branford, ct"
  }, 
  {
   "hits": 4, 
   "name": "warrenton, va"
  }, 
  {
   "hits": 4, 
   "name": "sharon, ma"
  }, 
  {
   "hits": 4, 
   "name": "hightstown, nj"
  }, 
  {
   "hits": 4, 
   "name": "north bergen, nj"
  }, 
  {
   "hits": 4, 
   "name": "howell, mi"
  }, 
  {
   "hits": 4, 
   "name": "new canaan, ct"
  }, 
  {
   "hits": 4, 
   "name": "overland park, ks"
  }, 
  {
   "hits": 4, 
   "name": "egg harbor township, nj"
  }, 
  {
   "hits": 4, 
   "name": "tustin, ca"
  }, 
  {
   "hits": 4, 
   "name": "moline, il"
  }, 
  {
   "hits": 4, 
   "name": "indio, ca"
  }, 
  {
   "hits": 4, 
   "name": "boyds, md"
  }, 
  {
   "hits": 4, 
   "name": "lehi, ut"
  }, 
  {
   "hits": 4, 
   "name": "santa paula, ca"
  }, 
  {
   "hits": 4, 
   "name": "atherton, ca"
  }, 
  {
   "hits": 4, 
   "name": "westfield, ma"
  }, 
  {
   "hits": 4, 
   "name": "covington, ky"
  }, 
  {
   "hits": 4, 
   "name": "arcata, ca"
  }, 
  {
   "hits": 4, 
   "name": "minnetonka, mn"
  }, 
  {
   "hits": 4, 
   "name": "honesdale, pa"
  }, 
  {
   "hits": 4, 
   "name": "pittsfield, ma"
  }, 
  {
   "hits": 4, 
   "name": "glendale heights, il"
  }, 
  {
   "hits": 4, 
   "name": "lake bluff, il"
  }, 
  {
   "hits": 4, 
   "name": "richmond, in"
  }, 
  {
   "hits": 4, 
   "name": "kingsport, tn"
  }, 
  {
   "hits": 4, 
   "name": "ormond beach, fl"
  }, 
  {
   "hits": 4, 
   "name": "waterbury, ct"
  }, 
  {
   "hits": 4, 
   "name": "columbia, tn"
  }, 
  {
   "hits": 4, 
   "name": "redding, ca"
  }, 
  {
   "hits": 4, 
   "name": "dublin, oh"
  }, 
  {
   "hits": 4, 
   "name": "san angelo, tx"
  }, 
  {
   "hits": 4, 
   "name": "altoona, pa"
  }, 
  {
   "hits": 4, 
   "name": "san juan capistrano, ca"
  }, 
  {
   "hits": 4, 
   "name": "manchester, ct"
  }, 
  {
   "hits": 4, 
   "name": "santa maria, ca"
  }, 
  {
   "hits": 4, 
   "name": "jefferson city, mo"
  }, 
  {
   "hits": 4, 
   "name": "south royalton, vt"
  }, 
  {
   "hits": 4, 
   "name": "parkville, md"
  }, 
  {
   "hits": 4, 
   "name": "south orange, nj"
  }, 
  {
   "hits": 4, 
   "name": "okemos, mi"
  }, 
  {
   "hits": 4, 
   "name": "fulton, mo"
  }, 
  {
   "hits": 4, 
   "name": "bellaire, tx"
  }, 
  {
   "hits": 4, 
   "name": "plymouth, ma"
  }, 
  {
   "hits": 4, 
   "name": "mclean, va"
  }, 
  {
   "hits": 4, 
   "name": "plymouth, mi"
  }, 
  {
   "hits": 4, 
   "name": "oak lawn, il"
  }, 
  {
   "hits": 4, 
   "name": "powell, oh"
  }, 
  {
   "hits": 4, 
   "name": "hackensack, nj"
  }, 
  {
   "hits": 4, 
   "name": "cathedral city, ca"
  }, 
  {
   "hits": 4, 
   "name": "hudson, ny"
  }, 
  {
   "hits": 4, 
   "name": "atlantic beach, fl"
  }, 
  {
   "hits": 4, 
   "name": "west roxbury, ma"
  }, 
  {
   "hits": 4, 
   "name": "helena, mt"
  }, 
  {
   "hits": 4, 
   "name": "east northport, ny"
  }, 
  {
   "hits": 4, 
   "name": "danville, va"
  }, 
  {
   "hits": 4, 
   "name": "westmont, il"
  }, 
  {
   "hits": 4, 
   "name": "vernon hills, il"
  }, 
  {
   "hits": 4, 
   "name": "sheboygan, wi"
  }, 
  {
   "hits": 4, 
   "name": "woodbridge, ct"
  }, 
  {
   "hits": 4, 
   "name": "wantagh, ny"
  }, 
  {
   "hits": 4, 
   "name": "augusta, ga"
  }, 
  {
   "hits": 4, 
   "name": "drexel hill, pa"
  }, 
  {
   "hits": 4, 
   "name": "hinckley, oh"
  }, 
  {
   "hits": 4, 
   "name": "longview, wa"
  }, 
  {
   "hits": 4, 
   "name": "joliet, il"
  }, 
  {
   "hits": 4, 
   "name": "bryan, tx"
  }, 
  {
   "hits": 4, 
   "name": "revere, ma"
  }, 
  {
   "hits": 4, 
   "name": "racine, wi"
  }, 
  {
   "hits": 4, 
   "name": "duluth, ga"
  }, 
  {
   "hits": 4, 
   "name": "pottstown, pa"
  }, 
  {
   "hits": 4, 
   "name": "north brunswick, nj"
  }, 
  {
   "hits": 4, 
   "name": "morgan hill, ca"
  }, 
  {
   "hits": 4, 
   "name": "copperas cove, tx"
  }, 
  {
   "hits": 4, 
   "name": "verona, wi"
  }, 
  {
   "hits": 4, 
   "name": "jenkintown, pa"
  }, 
  {
   "hits": 4, 
   "name": "summit, nj"
  }, 
  {
   "hits": 4, 
   "name": "medfield, ma"
  }, 
  {
   "hits": 4, 
   "name": "rochester, mi"
  }, 
  {
   "hits": 4, 
   "name": "apple valley, ca"
  }, 
  {
   "hits": 4, 
   "name": "saint cloud, mn"
  }, 
  {
   "hits": 4, 
   "name": "newport, ri"
  }, 
  {
   "hits": 4, 
   "name": "stow, ma"
  }, 
  {
   "hits": 4, 
   "name": "oregon city, or"
  }, 
  {
   "hits": 4, 
   "name": "new rochelle, ny"
  }, 
  {
   "hits": 4, 
   "name": "fort smith, ar"
  }, 
  {
   "hits": 4, 
   "name": "saratoga springs, ny"
  }, 
  {
   "hits": 4, 
   "name": "reading, ma"
  }, 
  {
   "hits": 4, 
   "name": "wakefield, ma"
  }, 
  {
   "hits": 4, 
   "name": "kensington, md"
  }, 
  {
   "hits": 4, 
   "name": "daytona beach, fl"
  }, 
  {
   "hits": 4, 
   "name": "cape elizabeth, me"
  }, 
  {
   "hits": 4, 
   "name": "madison, al"
  }, 
  {
   "hits": 4, 
   "name": "lakewood, oh"
  }, 
  {
   "hits": 4, 
   "name": "weirton, wv"
  }, 
  {
   "hits": 4, 
   "name": "anthem, az"
  }, 
  {
   "hits": 4, 
   "name": "bridgewater, ma"
  }, 
  {
   "hits": 4, 
   "name": "wildomar, ca"
  }, 
  {
   "hits": 4, 
   "name": ", in"
  }, 
  {
   "hits": 4, 
   "name": "huntington station, ny"
  }, 
  {
   "hits": 4, 
   "name": "el macero, ca"
  }, 
  {
   "hits": 4, 
   "name": "bayside, ny"
  }, 
  {
   "hits": 4, 
   "name": "lewisburg, pa"
  }, 
  {
   "hits": 4, 
   "name": "newbury park, ca"
  }, 
  {
   "hits": 4, 
   "name": "peoria, az"
  }, 
  {
   "hits": 4, 
   "name": "crystal lake, il"
  }, 
  {
   "hits": 4, 
   "name": "waban, ma"
  }, 
  {
   "hits": 4, 
   "name": "kailua, hi"
  }, 
  {
   "hits": 4, 
   "name": "mahwah, nj"
  }, 
  {
   "hits": 4, 
   "name": "glastonbury, ct"
  }, 
  {
   "hits": 4, 
   "name": "mahopac, ny"
  }, 
  {
   "hits": 4, 
   "name": "olathe, ks"
  }, 
  {
   "hits": 4, 
   "name": "clifton, nj"
  }, 
  {
   "hits": 4, 
   "name": "voorhees, nj"
  }, 
  {
   "hits": 4, 
   "name": "mansfield, oh"
  }, 
  {
   "hits": 4, 
   "name": "draper, ut"
  }, 
  {
   "hits": 4, 
   "name": "saint peters, mo"
  }, 
  {
   "hits": 4, 
   "name": "canton, ga"
  }, 
  {
   "hits": 4, 
   "name": "lincoln city, or"
  }, 
  {
   "hits": 4, 
   "name": "plainsboro, nj"
  }, 
  {
   "hits": 4, 
   "name": "antelope, ca"
  }, 
  {
   "hits": 4, 
   "name": "carmichael, ca"
  }, 
  {
   "hits": 4, 
   "name": "gainesville, ga"
  }, 
  {
   "hits": 4, 
   "name": "temecula, ca"
  }, 
  {
   "hits": 4, 
   "name": "los lunas, nm"
  }, 
  {
   "hits": 4, 
   "name": "cedar falls, ia"
  }, 
  {
   "hits": 4, 
   "name": "merced, ca"
  }, 
  {
   "hits": 4, 
   "name": "lafayette, ca"
  }, 
  {
   "hits": 4, 
   "name": "gurnee, il"
  }, 
  {
   "hits": 4, 
   "name": "warren, oh"
  }, 
  {
   "hits": 4, 
   "name": "clifton park, ny"
  }, 
  {
   "hits": 4, 
   "name": "wilton, ct"
  }, 
  {
   "hits": 4, 
   "name": "saint george, ut"
  }, 
  {
   "hits": 4, 
   "name": "bloomfield hills, mi"
  }, 
  {
   "hits": 4, 
   "name": "flanders, nj"
  }, 
  {
   "hits": 4, 
   "name": "carlisle, ma"
  }, 
  {
   "hits": 4, 
   "name": "hood river, or"
  }, 
  {
   "hits": 4, 
   "name": "edmond, ok"
  }, 
  {
   "hits": 4, 
   "name": "pueblo, co"
  }, 
  {
   "hits": 4, 
   "name": "hagerstown, md"
  }, 
  {
   "hits": 4, 
   "name": "janesville, wi"
  }, 
  {
   "hits": 4, 
   "name": "south pasadena, ca"
  }, 
  {
   "hits": 4, 
   "name": "vestal, ny"
  }, 
  {
   "hits": 4, 
   "name": "fallbrook, ca"
  }, 
  {
   "hits": 4, 
   "name": "o fallon, mo"
  }, 
  {
   "hits": 4, 
   "name": "cookeville, tn"
  }, 
  {
   "hits": 4, 
   "name": "palm harbor, fl"
  }, 
  {
   "hits": 4, 
   "name": "decatur, il"
  }, 
  {
   "hits": 4, 
   "name": "weymouth, ma"
  }, 
  {
   "hits": 4, 
   "name": "dobbs ferry, ny"
  }, 
  {
   "hits": 4, 
   "name": "gallatin, tn"
  }, 
  {
   "hits": 4, 
   "name": "mountlake terrace, wa"
  }, 
  {
   "hits": 4, 
   "name": "greeley, co"
  }, 
  {
   "hits": 4, 
   "name": "gig harbor, wa"
  }, 
  {
   "hits": 4, 
   "name": "yukon, ok"
  }, 
  {
   "hits": 4, 
   "name": "brattleboro, vt"
  }, 
  {
   "hits": 4, 
   "name": "port huron, mi"
  }, 
  {
   "hits": 4, 
   "name": "lockport, ny"
  }, 
  {
   "hits": 4, 
   "name": "scarsdale, ny"
  }, 
  {
   "hits": 4, 
   "name": "conyers, ga"
  }, 
  {
   "hits": 4, 
   "name": "new port richey, fl"
  }, 
  {
   "hits": 4, 
   "name": "el sobrante, ca"
  }, 
  {
   "hits": 4, 
   "name": "mount laurel, nj"
  }, 
  {
   "hits": 4, 
   "name": "yorktown, va"
  }, 
  {
   "hits": 4, 
   "name": "covina, ca"
  }, 
  {
   "hits": 4, 
   "name": "wayland, ma"
  }, 
  {
   "hits": 4, 
   "name": "bayonne, nj"
  }, 
  {
   "hits": 4, 
   "name": "zephyrhills, fl"
  }, 
  {
   "hits": 4, 
   "name": "morristown, nj"
  }, 
  {
   "hits": 4, 
   "name": "dana point, ca"
  }, 
  {
   "hits": 4, 
   "name": "converse, tx"
  }, 
  {
   "hits": 4, 
   "name": "mckinney, tx"
  }, 
  {
   "hits": 4, 
   "name": "penfield, ny"
  }, 
  {
   "hits": 4, 
   "name": "bowling green, ky"
  }, 
  {
   "hits": 4, 
   "name": "tracy, ca"
  }, 
  {
   "hits": 4, 
   "name": "cocoa beach, fl"
  }, 
  {
   "hits": 4, 
   "name": "grants pass, or"
  }, 
  {
   "hits": 4, 
   "name": "bedford, tx"
  }, 
  {
   "hits": 4, 
   "name": "glasgow, ky"
  }, 
  {
   "hits": 4, 
   "name": "woodland park, co"
  }, 
  {
   "hits": 4, 
   "name": "northborough, ma"
  }, 
  {
   "hits": 4, 
   "name": "cranston, ri"
  }, 
  {
   "hits": 4, 
   "name": "sandpoint, id"
  }, 
  {
   "hits": 4, 
   "name": ", mn"
  }, 
  {
   "hits": 3, 
   "name": "socorro, nm"
  }, 
  {
   "hits": 3, 
   "name": "douglasville, ga"
  }, 
  {
   "hits": 3, 
   "name": "burke, va"
  }, 
  {
   "hits": 3, 
   "name": "madison, ct"
  }, 
  {
   "hits": 3, 
   "name": "portsmouth, nh"
  }, 
  {
   "hits": 3, 
   "name": "lake mary, fl"
  }, 
  {
   "hits": 3, 
   "name": "new berlin, wi"
  }, 
  {
   "hits": 3, 
   "name": "haleiwa, hi"
  }, 
  {
   "hits": 3, 
   "name": "silvis, il"
  }, 
  {
   "hits": 3, 
   "name": "mount pleasant, mi"
  }, 
  {
   "hits": 3, 
   "name": "fair lawn, nj"
  }, 
  {
   "hits": 3, 
   "name": "oregon, wi"
  }, 
  {
   "hits": 3, 
   "name": "pitman, nj"
  }, 
  {
   "hits": 3, 
   "name": "alvin, tx"
  }, 
  {
   "hits": 3, 
   "name": "pickerington, oh"
  }, 
  {
   "hits": 3, 
   "name": "elgin, il"
  }, 
  {
   "hits": 3, 
   "name": "jackson, tn"
  }, 
  {
   "hits": 3, 
   "name": "greenlawn, ny"
  }, 
  {
   "hits": 3, 
   "name": "tujunga, ca"
  }, 
  {
   "hits": 3, 
   "name": "mcdonald, pa"
  }, 
  {
   "hits": 3, 
   "name": "westlake village, ca"
  }, 
  {
   "hits": 3, 
   "name": "florence, ma"
  }, 
  {
   "hits": 3, 
   "name": "hackettstown, nj"
  }, 
  {
   "hits": 3, 
   "name": "woonsocket, ri"
  }, 
  {
   "hits": 3, 
   "name": "massillon, oh"
  }, 
  {
   "hits": 3, 
   "name": "goodyear, az"
  }, 
  {
   "hits": 3, 
   "name": "cuyahoga falls, oh"
  }, 
  {
   "hits": 3, 
   "name": "bridge city, tx"
  }, 
  {
   "hits": 3, 
   "name": "lake saint louis, mo"
  }, 
  {
   "hits": 3, 
   "name": "crown point, in"
  }, 
  {
   "hits": 3, 
   "name": "pawling, ny"
  }, 
  {
   "hits": 3, 
   "name": "andover, mn"
  }, 
  {
   "hits": 3, 
   "name": "hershey, pa"
  }, 
  {
   "hits": 3, 
   "name": "birmingham, mi"
  }, 
  {
   "hits": 3, 
   "name": "buena park, ca"
  }, 
  {
   "hits": 3, 
   "name": "leominster, ma"
  }, 
  {
   "hits": 3, 
   "name": "melville, ny"
  }, 
  {
   "hits": 3, 
   "name": "swarthmore, pa"
  }, 
  {
   "hits": 3, 
   "name": "cary, il"
  }, 
  {
   "hits": 3, 
   "name": "west covina, ca"
  }, 
  {
   "hits": 3, 
   "name": "quakertown, pa"
  }, 
  {
   "hits": 3, 
   "name": "merritt island, fl"
  }, 
  {
   "hits": 3, 
   "name": "harrison, nj"
  }, 
  {
   "hits": 3, 
   "name": "levittown, pa"
  }, 
  {
   "hits": 3, 
   "name": "richmond hill, ga"
  }, 
  {
   "hits": 3, 
   "name": "oakland gardens, ny"
  }, 
  {
   "hits": 3, 
   "name": "waldwick, nj"
  }, 
  {
   "hits": 3, 
   "name": "rathdrum, id"
  }, 
  {
   "hits": 3, 
   "name": "ashtabula, oh"
  }, 
  {
   "hits": 3, 
   "name": "millburn, nj"
  }, 
  {
   "hits": 3, 
   "name": "monsey, ny"
  }, 
  {
   "hits": 3, 
   "name": "burlington, nc"
  }, 
  {
   "hits": 3, 
   "name": "irwin, pa"
  }, 
  {
   "hits": 3, 
   "name": "salisbury, nc"
  }, 
  {
   "hits": 3, 
   "name": "norwich, ct"
  }, 
  {
   "hits": 3, 
   "name": "fenton, mi"
  }, 
  {
   "hits": 3, 
   "name": "coarsegold, ca"
  }, 
  {
   "hits": 3, 
   "name": "erie, co"
  }, 
  {
   "hits": 3, 
   "name": "braintree, ma"
  }, 
  {
   "hits": 3, 
   "name": "post falls, id"
  }, 
  {
   "hits": 3, 
   "name": "dubuque, ia"
  }, 
  {
   "hits": 3, 
   "name": "oxford, ms"
  }, 
  {
   "hits": 3, 
   "name": "midland, tx"
  }, 
  {
   "hits": 3, 
   "name": "north little rock, ar"
  }, 
  {
   "hits": 3, 
   "name": "satellite beach, fl"
  }, 
  {
   "hits": 3, 
   "name": "pembroke pines, fl"
  }, 
  {
   "hits": 3, 
   "name": "geneva, ny"
  }, 
  {
   "hits": 3, 
   "name": "glen mills, pa"
  }, 
  {
   "hits": 3, 
   "name": "excelsior springs, mo"
  }, 
  {
   "hits": 3, 
   "name": "north augusta, sc"
  }, 
  {
   "hits": 3, 
   "name": "key west, fl"
  }, 
  {
   "hits": 3, 
   "name": "waterville, me"
  }, 
  {
   "hits": 3, 
   "name": "riverton, ut"
  }, 
  {
   "hits": 3, 
   "name": "brunswick, me"
  }, 
  {
   "hits": 3, 
   "name": "soquel, ca"
  }, 
  {
   "hits": 3, 
   "name": "barnegat, nj"
  }, 
  {
   "hits": 3, 
   "name": "garner, nc"
  }, 
  {
   "hits": 3, 
   "name": "arden, nc"
  }, 
  {
   "hits": 3, 
   "name": "los osos, ca"
  }, 
  {
   "hits": 3, 
   "name": "la crosse, wi"
  }, 
  {
   "hits": 3, 
   "name": "la porte, in"
  }, 
  {
   "hits": 3, 
   "name": "shreveport, la"
  }, 
  {
   "hits": 3, 
   "name": "midland, mi"
  }, 
  {
   "hits": 3, 
   "name": "derry, nh"
  }, 
  {
   "hits": 3, 
   "name": "chalfont, pa"
  }, 
  {
   "hits": 3, 
   "name": "west columbia, sc"
  }, 
  {
   "hits": 3, 
   "name": "river falls, wi"
  }, 
  {
   "hits": 3, 
   "name": "munster, in"
  }, 
  {
   "hits": 3, 
   "name": "glen cove, ny"
  }, 
  {
   "hits": 3, 
   "name": "farmville, va"
  }, 
  {
   "hits": 3, 
   "name": ", pa"
  }, 
  {
   "hits": 3, 
   "name": "northville, mi"
  }, 
  {
   "hits": 3, 
   "name": "camas, wa"
  }, 
  {
   "hits": 3, 
   "name": "nyack, ny"
  }, 
  {
   "hits": 3, 
   "name": "palm coast, fl"
  }, 
  {
   "hits": 3, 
   "name": "eagle river, ak"
  }, 
  {
   "hits": 3, 
   "name": "franklin, ma"
  }, 
  {
   "hits": 3, 
   "name": "ridgefield, nj"
  }, 
  {
   "hits": 3, 
   "name": "rutland, ma"
  }, 
  {
   "hits": 3, 
   "name": "michigan city, in"
  }, 
  {
   "hits": 3, 
   "name": "rockledge, fl"
  }, 
  {
   "hits": 3, 
   "name": "cotati, ca"
  }, 
  {
   "hits": 3, 
   "name": "hendersonville, tn"
  }, 
  {
   "hits": 3, 
   "name": "accord, ny"
  }, 
  {
   "hits": 3, 
   "name": "spotsylvania, va"
  }, 
  {
   "hits": 3, 
   "name": "watervliet, ny"
  }, 
  {
   "hits": 3, 
   "name": "west jordan, ut"
  }, 
  {
   "hits": 3, 
   "name": "san marcos, ca"
  }, 
  {
   "hits": 3, 
   "name": "oceanside, ny"
  }, 
  {
   "hits": 3, 
   "name": "delmar, ny"
  }, 
  {
   "hits": 3, 
   "name": "bismarck, nd"
  }, 
  {
   "hits": 3, 
   "name": "manteca, ca"
  }, 
  {
   "hits": 3, 
   "name": "wrentham, ma"
  }, 
  {
   "hits": 3, 
   "name": "kailua kona, hi"
  }, 
  {
   "hits": 3, 
   "name": "placerville, ca"
  }, 
  {
   "hits": 3, 
   "name": "huntington, ny"
  }, 
  {
   "hits": 3, 
   "name": "pittsboro, nc"
  }, 
  {
   "hits": 3, 
   "name": "wasilla, ak"
  }, 
  {
   "hits": 3, 
   "name": "coralville, ia"
  }, 
  {
   "hits": 3, 
   "name": "earlysville, va"
  }, 
  {
   "hits": 3, 
   "name": "fredericksburg, tx"
  }, 
  {
   "hits": 3, 
   "name": "suffolk, va"
  }, 
  {
   "hits": 3, 
   "name": "lehigh acres, fl"
  }, 
  {
   "hits": 3, 
   "name": "port orange, fl"
  }, 
  {
   "hits": 3, 
   "name": "marysville, oh"
  }, 
  {
   "hits": 3, 
   "name": "stoughton, ma"
  }, 
  {
   "hits": 3, 
   "name": "new brunswick, nj"
  }, 
  {
   "hits": 3, 
   "name": "commerce township, mi"
  }, 
  {
   "hits": 3, 
   "name": "fort lee, nj"
  }, 
  {
   "hits": 3, 
   "name": "menifee, ca"
  }, 
  {
   "hits": 3, 
   "name": "darien, ct"
  }, 
  {
   "hits": 3, 
   "name": "avon, ct"
  }, 
  {
   "hits": 3, 
   "name": "maryville, tn"
  }, 
  {
   "hits": 3, 
   "name": "linthicum heights, md"
  }, 
  {
   "hits": 3, 
   "name": "port jefferson, ny"
  }, 
  {
   "hits": 3, 
   "name": "evergreen, co"
  }, 
  {
   "hits": 3, 
   "name": "college point, ny"
  }, 
  {
   "hits": 3, 
   "name": "valparaiso, in"
  }, 
  {
   "hits": 3, 
   "name": "sylmar, ca"
  }, 
  {
   "hits": 3, 
   "name": "north wales, pa"
  }, 
  {
   "hits": 3, 
   "name": "westlake, oh"
  }, 
  {
   "hits": 3, 
   "name": "winsted, ct"
  }, 
  {
   "hits": 3, 
   "name": "westminster, md"
  }, 
  {
   "hits": 3, 
   "name": "greenwich, ny"
  }, 
  {
   "hits": 3, 
   "name": "milford, ma"
  }, 
  {
   "hits": 3, 
   "name": "victoria, tx"
  }, 
  {
   "hits": 3, 
   "name": "metuchen, nj"
  }, 
  {
   "hits": 3, 
   "name": "trumbull, ct"
  }, 
  {
   "hits": 3, 
   "name": "half moon bay, ca"
  }, 
  {
   "hits": 3, 
   "name": "intervale, nh"
  }, 
  {
   "hits": 3, 
   "name": "new city, ny"
  }, 
  {
   "hits": 3, 
   "name": "dryden, ny"
  }, 
  {
   "hits": 3, 
   "name": "dover, nh"
  }, 
  {
   "hits": 3, 
   "name": "bay saint louis, ms"
  }, 
  {
   "hits": 3, 
   "name": "chelmsford, ma"
  }, 
  {
   "hits": 3, 
   "name": "grafton, wi"
  }, 
  {
   "hits": 3, 
   "name": "middletown, md"
  }, 
  {
   "hits": 3, 
   "name": "gulf shores, al"
  }, 
  {
   "hits": 3, 
   "name": "abingdon, va"
  }, 
  {
   "hits": 3, 
   "name": "ridgewood, ny"
  }, 
  {
   "hits": 3, 
   "name": "brooksville, fl"
  }, 
  {
   "hits": 3, 
   "name": "burlington, ma"
  }, 
  {
   "hits": 3, 
   "name": "merrick, ny"
  }, 
  {
   "hits": 3, 
   "name": "woodridge, il"
  }, 
  {
   "hits": 3, 
   "name": "windom, mn"
  }, 
  {
   "hits": 3, 
   "name": "aubrey, tx"
  }, 
  {
   "hits": 3, 
   "name": "la honda, ca"
  }, 
  {
   "hits": 3, 
   "name": "pepperell, ma"
  }, 
  {
   "hits": 3, 
   "name": "bucyrus, oh"
  }, 
  {
   "hits": 3, 
   "name": "mcallen, tx"
  }, 
  {
   "hits": 3, 
   "name": "trabuco canyon, ca"
  }, 
  {
   "hits": 3, 
   "name": "rockford, mi"
  }, 
  {
   "hits": 3, 
   "name": "painesville, oh"
  }, 
  {
   "hits": 3, 
   "name": "niceville, fl"
  }, 
  {
   "hits": 3, 
   "name": "billerica, ma"
  }, 
  {
   "hits": 3, 
   "name": "williamstown, nj"
  }, 
  {
   "hits": 3, 
   "name": "sun prairie, wi"
  }, 
  {
   "hits": 3, 
   "name": "edwardsville, il"
  }, 
  {
   "hits": 3, 
   "name": "stevens, pa"
  }, 
  {
   "hits": 3, 
   "name": "new albany, in"
  }, 
  {
   "hits": 3, 
   "name": "suffern, ny"
  }, 
  {
   "hits": 3, 
   "name": "weaverville, nc"
  }, 
  {
   "hits": 3, 
   "name": "east providence, ri"
  }, 
  {
   "hits": 3, 
   "name": "delaware, oh"
  }, 
  {
   "hits": 3, 
   "name": "foxboro, ma"
  }, 
  {
   "hits": 3, 
   "name": "fairfield, ca"
  }, 
  {
   "hits": 3, 
   "name": "fayetteville, nc"
  }, 
  {
   "hits": 3, 
   "name": "groveland, ma"
  }, 
  {
   "hits": 3, 
   "name": "canonsburg, pa"
  }, 
  {
   "hits": 3, 
   "name": "liberty, mo"
  }, 
  {
   "hits": 3, 
   "name": "chino hills, ca"
  }, 
  {
   "hits": 3, 
   "name": "hamden, ct"
  }, 
  {
   "hits": 3, 
   "name": "spokane valley, wa"
  }, 
  {
   "hits": 3, 
   "name": "chelsea, mi"
  }, 
  {
   "hits": 3, 
   "name": "midlothian, il"
  }, 
  {
   "hits": 3, 
   "name": "westport, ct"
  }, 
  {
   "hits": 3, 
   "name": "university park, pa"
  }, 
  {
   "hits": 3, 
   "name": "rancho santa fe, ca"
  }, 
  {
   "hits": 3, 
   "name": "new lenox, il"
  }, 
  {
   "hits": 3, 
   "name": ", or"
  }, 
  {
   "hits": 3, 
   "name": "upper marlboro, md"
  }, 
  {
   "hits": 3, 
   "name": "wheeling, il"
  }, 
  {
   "hits": 3, 
   "name": "merrimack, nh"
  }, 
  {
   "hits": 3, 
   "name": "west hills, ca"
  }, 
  {
   "hits": 3, 
   "name": "manistee, mi"
  }, 
  {
   "hits": 3, 
   "name": "woodstock, ny"
  }, 
  {
   "hits": 3, 
   "name": "winston-salem, nc"
  }, 
  {
   "hits": 3, 
   "name": "tewksbury, ma"
  }, 
  {
   "hits": 3, 
   "name": "ronkonkoma, ny"
  }, 
  {
   "hits": 3, 
   "name": "upper darby, pa"
  }, 
  {
   "hits": 3, 
   "name": "menomonee falls, wi"
  }, 
  {
   "hits": 3, 
   "name": "naugatuck, ct"
  }, 
  {
   "hits": 3, 
   "name": "grosse pointe, mi"
  }, 
  {
   "hits": 3, 
   "name": "montebello, ca"
  }, 
  {
   "hits": 3, 
   "name": "newton highlands, ma"
  }, 
  {
   "hits": 3, 
   "name": "milford, ct"
  }, 
  {
   "hits": 3, 
   "name": "rock hill, sc"
  }, 
  {
   "hits": 3, 
   "name": "new freedom, pa"
  }, 
  {
   "hits": 3, 
   "name": "somerset, nj"
  }, 
  {
   "hits": 3, 
   "name": "franklin, wi"
  }, 
  {
   "hits": 3, 
   "name": "clemson, sc"
  }, 
  {
   "hits": 3, 
   "name": ", oh"
  }, 
  {
   "hits": 3, 
   "name": "cudahy, wi"
  }, 
  {
   "hits": 3, 
   "name": "shrewsbury, ma"
  }, 
  {
   "hits": 3, 
   "name": "ridgefield, ct"
  }, 
  {
   "hits": 3, 
   "name": "washington, il"
  }, 
  {
   "hits": 3, 
   "name": "hailey, id"
  }, 
  {
   "hits": 3, 
   "name": "lincolnwood, il"
  }, 
  {
   "hits": 3, 
   "name": "navarre, fl"
  }, 
  {
   "hits": 3, 
   "name": "hamilton, oh"
  }, 
  {
   "hits": 3, 
   "name": "hummelstown, pa"
  }, 
  {
   "hits": 3, 
   "name": "north port, fl"
  }, 
  {
   "hits": 3, 
   "name": "battle creek, mi"
  }, 
  {
   "hits": 3, 
   "name": "eastchester, ny"
  }, 
  {
   "hits": 3, 
   "name": "steilacoom, wa"
  }, 
  {
   "hits": 3, 
   "name": "chalmette, la"
  }, 
  {
   "hits": 3, 
   "name": "bartlett, il"
  }, 
  {
   "hits": 3, 
   "name": "severn, md"
  }, 
  {
   "hits": 3, 
   "name": "ladera ranch, ca"
  }, 
  {
   "hits": 3, 
   "name": "topanga, ca"
  }, 
  {
   "hits": 3, 
   "name": "venice, fl"
  }, 
  {
   "hits": 3, 
   "name": "great falls, mt"
  }, 
  {
   "hits": 3, 
   "name": "santa clarita, ca"
  }, 
  {
   "hits": 3, 
   "name": "vail, az"
  }, 
  {
   "hits": 3, 
   "name": "columbus, in"
  }, 
  {
   "hits": 3, 
   "name": "new hyde park, ny"
  }, 
  {
   "hits": 3, 
   "name": "cordova, tn"
  }, 
  {
   "hits": 3, 
   "name": "carnegie, pa"
  }, 
  {
   "hits": 3, 
   "name": "garden city, mi"
  }, 
  {
   "hits": 3, 
   "name": "plainview, ny"
  }, 
  {
   "hits": 3, 
   "name": "carson, ca"
  }, 
  {
   "hits": 3, 
   "name": "dover, ma"
  }, 
  {
   "hits": 3, 
   "name": "pipersville, pa"
  }, 
  {
   "hits": 3, 
   "name": "new albany, oh"
  }, 
  {
   "hits": 3, 
   "name": "rancho santa margarita, ca"
  }, 
  {
   "hits": 3, 
   "name": "parsippany, nj"
  }, 
  {
   "hits": 3, 
   "name": "centennial, co"
  }, 
  {
   "hits": 3, 
   "name": "sanford, fl"
  }, 
  {
   "hits": 3, 
   "name": "muskegon, mi"
  }, 
  {
   "hits": 3, 
   "name": "oswego, ny"
  }, 
  {
   "hits": 3, 
   "name": "farmington, mi"
  }, 
  {
   "hits": 3, 
   "name": "latham, ny"
  }, 
  {
   "hits": 3, 
   "name": "roswell, nm"
  }, 
  {
   "hits": 3, 
   "name": "aberdeen, md"
  }, 
  {
   "hits": 3, 
   "name": "wylie, tx"
  }, 
  {
   "hits": 3, 
   "name": "west islip, ny"
  }, 
  {
   "hits": 3, 
   "name": "montgomery, ny"
  }, 
  {
   "hits": 3, 
   "name": "miamisburg, oh"
  }, 
  {
   "hits": 3, 
   "name": "dundee, il"
  }, 
  {
   "hits": 3, 
   "name": "natchitoches, la"
  }, 
  {
   "hits": 3, 
   "name": "matthews, nc"
  }, 
  {
   "hits": 3, 
   "name": "calabasas, ca"
  }, 
  {
   "hits": 3, 
   "name": "mantua, nj"
  }, 
  {
   "hits": 3, 
   "name": "hacienda heights, ca"
  }, 
  {
   "hits": 3, 
   "name": "arnold, md"
  }, 
  {
   "hits": 3, 
   "name": "morganton, nc"
  }, 
  {
   "hits": 3, 
   "name": "gretna, la"
  }, 
  {
   "hits": 3, 
   "name": "greenbelt, md"
  }, 
  {
   "hits": 3, 
   "name": "glen ellyn, il"
  }, 
  {
   "hits": 3, 
   "name": "hillsboro, oh"
  }, 
  {
   "hits": 3, 
   "name": "franklin lakes, nj"
  }, 
  {
   "hits": 3, 
   "name": "lake elsinore, ca"
  }, 
  {
   "hits": 3, 
   "name": "lutz, fl"
  }, 
  {
   "hits": 3, 
   "name": "buford, ga"
  }, 
  {
   "hits": 3, 
   "name": "anacortes, wa"
  }, 
  {
   "hits": 3, 
   "name": "milton, ma"
  }, 
  {
   "hits": 3, 
   "name": "alton, il"
  }, 
  {
   "hits": 3, 
   "name": "imperial beach, ca"
  }, 
  {
   "hits": 3, 
   "name": "rahway, nj"
  }, 
  {
   "hits": 3, 
   "name": "pineville, nc"
  }, 
  {
   "hits": 3, 
   "name": "dillsburg, pa"
  }, 
  {
   "hits": 3, 
   "name": "bear, de"
  }, 
  {
   "hits": 3, 
   "name": "monterey park, ca"
  }, 
  {
   "hits": 3, 
   "name": "hilo, hi"
  }, 
  {
   "hits": 3, 
   "name": "phoenixville, pa"
  }, 
  {
   "hits": 3, 
   "name": "hobbs, nm"
  }, 
  {
   "hits": 3, 
   "name": "friday harbor, wa"
  }, 
  {
   "hits": 3, 
   "name": "leesburg, fl"
  }, 
  {
   "hits": 3, 
   "name": "lawrenceburg, in"
  }, 
  {
   "hits": 3, 
   "name": "belvedere tiburon, ca"
  }, 
  {
   "hits": 3, 
   "name": "marion, ia"
  }, 
  {
   "hits": 3, 
   "name": "utica, mi"
  }, 
  {
   "hits": 3, 
   "name": "avondale, az"
  }, 
  {
   "hits": 3, 
   "name": "pikeville, ky"
  }, 
  {
   "hits": 3, 
   "name": "stratham, nh"
  }, 
  {
   "hits": 3, 
   "name": "richland, wa"
  }, 
  {
   "hits": 3, 
   "name": "christmas, fl"
  }, 
  {
   "hits": 3, 
   "name": "urbana, oh"
  }, 
  {
   "hits": 3, 
   "name": "denham springs, la"
  }, 
  {
   "hits": 3, 
   "name": "rome, ga"
  }, 
  {
   "hits": 3, 
   "name": "orange beach, al"
  }, 
  {
   "hits": 3, 
   "name": "morganville, nj"
  }, 
  {
   "hits": 3, 
   "name": "exeter, nh"
  }, 
  {
   "hits": 3, 
   "name": "scottsbluff, ne"
  }, 
  {
   "hits": 3, 
   "name": "greensburg, pa"
  }, 
  {
   "hits": 3, 
   "name": "pikesville, md"
  }, 
  {
   "hits": 3, 
   "name": "myrtle beach, sc"
  }, 
  {
   "hits": 3, 
   "name": "monroe, wa"
  }, 
  {
   "hits": 3, 
   "name": "swartz creek, mi"
  }, 
  {
   "hits": 3, 
   "name": "longmeadow, ma"
  }, 
  {
   "hits": 3, 
   "name": "rego park, ny"
  }, 
  {
   "hits": 3, 
   "name": "mokena, il"
  }, 
  {
   "hits": 3, 
   "name": "spring valley, ca"
  }, 
  {
   "hits": 3, 
   "name": "laguna hills, ca"
  }, 
  {
   "hits": 3, 
   "name": "blairstown, nj"
  }, 
  {
   "hits": 3, 
   "name": "shingle springs, ca"
  }, 
  {
   "hits": 3, 
   "name": "somers, ny"
  }, 
  {
   "hits": 3, 
   "name": "stoughton, wi"
  }, 
  {
   "hits": 3, 
   "name": "tarzana, ca"
  }, 
  {
   "hits": 3, 
   "name": "rossville, ga"
  }, 
  {
   "hits": 3, 
   "name": "fontana, ca"
  }, 
  {
   "hits": 3, 
   "name": "brookville, pa"
  }, 
  {
   "hits": 3, 
   "name": "moscow, id"
  }, 
  {
   "hits": 3, 
   "name": "pearland, tx"
  }, 
  {
   "hits": 3, 
   "name": "brookfield, ct"
  }, 
  {
   "hits": 3, 
   "name": "port angeles, wa"
  }, 
  {
   "hits": 3, 
   "name": "new braunfels, tx"
  }, 
  {
   "hits": 3, 
   "name": "porterville, ca"
  }, 
  {
   "hits": 3, 
   "name": "marina, ca"
  }, 
  {
   "hits": 3, 
   "name": "newport, or"
  }, 
  {
   "hits": 3, 
   "name": "middletown, ct"
  }, 
  {
   "hits": 3, 
   "name": "marion, oh"
  }, 
  {
   "hits": 3, 
   "name": "goose creek, sc"
  }, 
  {
   "hits": 3, 
   "name": "dedham, ma"
  }, 
  {
   "hits": 3, 
   "name": "stockton, nj"
  }, 
  {
   "hits": 3, 
   "name": "haverford, pa"
  }, 
  {
   "hits": 3, 
   "name": "orange city, fl"
  }, 
  {
   "hits": 3, 
   "name": "stafford, va"
  }, 
  {
   "hits": 3, 
   "name": "eatontown, nj"
  }, 
  {
   "hits": 3, 
   "name": "valley stream, ny"
  }, 
  {
   "hits": 3, 
   "name": "east brunswick, nj"
  }, 
  {
   "hits": 3, 
   "name": "port orchard, wa"
  }, 
  {
   "hits": 3, 
   "name": "lagunitas, ca"
  }, 
  {
   "hits": 3, 
   "name": "denison, tx"
  }, 
  {
   "hits": 3, 
   "name": "collingswood, nj"
  }, 
  {
   "hits": 3, 
   "name": "wheat ridge, co"
  }, 
  {
   "hits": 3, 
   "name": "lake forest, ca"
  }, 
  {
   "hits": 3, 
   "name": "scarborough, me"
  }, 
  {
   "hits": 3, 
   "name": "astoria, or"
  }, 
  {
   "hits": 3, 
   "name": "oviedo, fl"
  }, 
  {
   "hits": 3, 
   "name": "brockton, ma"
  }, 
  {
   "hits": 3, 
   "name": "hendersonville, nc"
  }, 
  {
   "hits": 3, 
   "name": "salina, ks"
  }, 
  {
   "hits": 3, 
   "name": "benicia, ca"
  }, 
  {
   "hits": 3, 
   "name": "el dorado hills, ca"
  }, 
  {
   "hits": 3, 
   "name": "dade city, fl"
  }, 
  {
   "hits": 3, 
   "name": "westland, mi"
  }, 
  {
   "hits": 3, 
   "name": "meridian, id"
  }, 
  {
   "hits": 3, 
   "name": "palisades park, nj"
  }, 
  {
   "hits": 3, 
   "name": "cabot, ar"
  }, 
  {
   "hits": 3, 
   "name": "sudbury, ma"
  }, 
  {
   "hits": 3, 
   "name": "bay city, mi"
  }, 
  {
   "hits": 3, 
   "name": "new britain, ct"
  }, 
  {
   "hits": 3, 
   "name": "ossining, ny"
  }, 
  {
   "hits": 3, 
   "name": "yuma, az"
  }, 
  {
   "hits": 3, 
   "name": "warminster, pa"
  }, 
  {
   "hits": 3, 
   "name": "mount airy, md"
  }, 
  {
   "hits": 3, 
   "name": "elkhart, in"
  }, 
  {
   "hits": 3, 
   "name": "florissant, mo"
  }, 
  {
   "hits": 3, 
   "name": "eden prairie, mn"
  }, 
  {
   "hits": 3, 
   "name": "hillsborough, nc"
  }, 
  {
   "hits": 3, 
   "name": "wilson, wy"
  }, 
  {
   "hits": 3, 
   "name": "south elgin, il"
  }, 
  {
   "hits": 3, 
   "name": "old bridge, nj"
  }, 
  {
   "hits": 3, 
   "name": "wenatchee, wa"
  }, 
  {
   "hits": 3, 
   "name": "incline village, nv"
  }, 
  {
   "hits": 3, 
   "name": "colleyville, tx"
  }, 
  {
   "hits": 3, 
   "name": "west haven, ct"
  }, 
  {
   "hits": 3, 
   "name": "grass valley, ca"
  }, 
  {
   "hits": 3, 
   "name": "mission, tx"
  }, 
  {
   "hits": 3, 
   "name": "harrison, tn"
  }, 
  {
   "hits": 3, 
   "name": "marlton, nj"
  }, 
  {
   "hits": 3, 
   "name": "portola valley, ca"
  }, 
  {
   "hits": 3, 
   "name": "mount dora, fl"
  }, 
  {
   "hits": 3, 
   "name": "king of prussia, pa"
  }, 
  {
   "hits": 3, 
   "name": "morton grove, il"
  }, 
  {
   "hits": 3, 
   "name": "lone tree, co"
  }, 
  {
   "hits": 3, 
   "name": "spearfish, sd"
  }, 
  {
   "hits": 3, 
   "name": "cocoa, fl"
  }, 
  {
   "hits": 3, 
   "name": "las vegas, nm"
  }, 
  {
   "hits": 3, 
   "name": "prior lake, mn"
  }, 
  {
   "hits": 3, 
   "name": "owensboro, ky"
  }, 
  {
   "hits": 3, 
   "name": "hudson, ma"
  }, 
  {
   "hits": 3, 
   "name": "walla walla, or"
  }, 
  {
   "hits": 3, 
   "name": "glendora, ca"
  }, 
  {
   "hits": 3, 
   "name": "port charlotte, fl"
  }, 
  {
   "hits": 3, 
   "name": "cartersville, ga"
  }, 
  {
   "hits": 3, 
   "name": "chester, ny"
  }, 
  {
   "hits": 3, 
   "name": "normal, il"
  }, 
  {
   "hits": 3, 
   "name": "deerfield beach, fl"
  }, 
  {
   "hits": 3, 
   "name": "grand prairie, tx"
  }, 
  {
   "hits": 3, 
   "name": "valrico, fl"
  }, 
  {
   "hits": 3, 
   "name": "bellerose, ny"
  }, 
  {
   "hits": 3, 
   "name": "dover, de"
  }, 
  {
   "hits": 3, 
   "name": "glencoe, il"
  }, 
  {
   "hits": 3, 
   "name": "oakton, va"
  }, 
  {
   "hits": 3, 
   "name": "edinburg, tx"
  }, 
  {
   "hits": 3, 
   "name": "fresh meadows, ny"
  }, 
  {
   "hits": 3, 
   "name": "chester, va"
  }, 
  {
   "hits": 3, 
   "name": "galesburg, il"
  }, 
  {
   "hits": 3, 
   "name": "auburn, wa"
  }, 
  {
   "hits": 3, 
   "name": "ukiah, ca"
  }, 
  {
   "hits": 3, 
   "name": "montgomery, al"
  }, 
  {
   "hits": 3, 
   "name": "newnan, ga"
  }, 
  {
   "hits": 3, 
   "name": "gladstone, or"
  }, 
  {
   "hits": 3, 
   "name": "yucaipa, ca"
  }, 
  {
   "hits": 3, 
   "name": "springfield, or"
  }, 
  {
   "hits": 3, 
   "name": "fall river, ma"
  }, 
  {
   "hits": 3, 
   "name": "vero beach, fl"
  }, 
  {
   "hits": 3, 
   "name": "hammond, la"
  }, 
  {
   "hits": 3, 
   "name": "hilton head island, sc"
  }, 
  {
   "hits": 3, 
   "name": "moab, ut"
  }, 
  {
   "hits": 3, 
   "name": "springfield, pa"
  }, 
  {
   "hits": 3, 
   "name": "hinsdale, il"
  }, 
  {
   "hits": 3, 
   "name": "carmel, ca"
  }, 
  {
   "hits": 3, 
   "name": "mableton, ga"
  }, 
  {
   "hits": 3, 
   "name": "buda, tx"
  }, 
  {
   "hits": 3, 
   "name": "wadsworth, oh"
  }, 
  {
   "hits": 3, 
   "name": "woodbury, nj"
  }, 
  {
   "hits": 3, 
   "name": "lindenhurst, ny"
  }, 
  {
   "hits": 3, 
   "name": "kennewick, wa"
  }, 
  {
   "hits": 3, 
   "name": "plainfield, il"
  }, 
  {
   "hits": 2, 
   "name": "jasper, ga"
  }, 
  {
   "hits": 2, 
   "name": "chicopee, ma"
  }, 
  {
   "hits": 2, 
   "name": "mason city, ia"
  }, 
  {
   "hits": 2, 
   "name": "moorpark, ca"
  }, 
  {
   "hits": 2, 
   "name": "oxford, oh"
  }, 
  {
   "hits": 2, 
   "name": "albrightsville, pa"
  }, 
  {
   "hits": 2, 
   "name": "riverside, nj"
  }, 
  {
   "hits": 2, 
   "name": "la verne, ca"
  }, 
  {
   "hits": 2, 
   "name": "uniontown, oh"
  }, 
  {
   "hits": 2, 
   "name": "saint helena, ca"
  }, 
  {
   "hits": 2, 
   "name": "dundalk, md"
  }, 
  {
   "hits": 2, 
   "name": "clifton, va"
  }, 
  {
   "hits": 2, 
   "name": "phenix city, al"
  }, 
  {
   "hits": 2, 
   "name": "hiawatha, ia"
  }, 
  {
   "hits": 2, 
   "name": "rolla, mo"
  }, 
  {
   "hits": 2, 
   "name": "lebanon, in"
  }, 
  {
   "hits": 2, 
   "name": "hutchinson, ks"
  }, 
  {
   "hits": 2, 
   "name": "little elm, tx"
  }, 
  {
   "hits": 2, 
   "name": "frazier park, ca"
  }, 
  {
   "hits": 2, 
   "name": "south yarmouth, ma"
  }, 
  {
   "hits": 2, 
   "name": "sun city, ca"
  }, 
  {
   "hits": 2, 
   "name": "whitehall, pa"
  }, 
  {
   "hits": 2, 
   "name": "solana beach, ca"
  }, 
  {
   "hits": 2, 
   "name": "abingdon, md"
  }, 
  {
   "hits": 2, 
   "name": "land o' lakes, fl"
  }, 
  {
   "hits": 2, 
   "name": "fort davis, tx"
  }, 
  {
   "hits": 2, 
   "name": "hazlet, nj"
  }, 
  {
   "hits": 2, 
   "name": "hereford, az"
  }, 
  {
   "hits": 2, 
   "name": "windsor, co"
  }, 
  {
   "hits": 2, 
   "name": "trussville, al"
  }, 
  {
   "hits": 2, 
   "name": "victor, ny"
  }, 
  {
   "hits": 2, 
   "name": "georgetown, ma"
  }, 
  {
   "hits": 2, 
   "name": "laramie, wy"
  }, 
  {
   "hits": 2, 
   "name": "roscoe, il"
  }, 
  {
   "hits": 2, 
   "name": "sun city center, fl"
  }, 
  {
   "hits": 2, 
   "name": "sunland, ca"
  }, 
  {
   "hits": 2, 
   "name": "greenfield, ma"
  }, 
  {
   "hits": 2, 
   "name": "falmouth, ma"
  }, 
  {
   "hits": 2, 
   "name": "baldwin, ny"
  }, 
  {
   "hits": 2, 
   "name": "plant city, fl"
  }, 
  {
   "hits": 2, 
   "name": "valdosta, ga"
  }, 
  {
   "hits": 2, 
   "name": "newport, ky"
  }, 
  {
   "hits": 2, 
   "name": "wooster, oh"
  }, 
  {
   "hits": 2, 
   "name": "creedmoor, nc"
  }, 
  {
   "hits": 2, 
   "name": "prairieville, la"
  }, 
  {
   "hits": 2, 
   "name": "kaneohe, hi"
  }, 
  {
   "hits": 2, 
   "name": "whitehouse station, nj"
  }, 
  {
   "hits": 2, 
   "name": "oak brook, il"
  }, 
  {
   "hits": 2, 
   "name": "silver city, nm"
  }, 
  {
   "hits": 2, 
   "name": "rockland, me"
  }, 
  {
   "hits": 2, 
   "name": "hinsdale, ma"
  }, 
  {
   "hits": 2, 
   "name": "gloucester, va"
  }, 
  {
   "hits": 2, 
   "name": "inverness, ca"
  }, 
  {
   "hits": 2, 
   "name": "chappaqua, ny"
  }, 
  {
   "hits": 2, 
   "name": "middle village, ny"
  }, 
  {
   "hits": 2, 
   "name": "sturgeon bay, wi"
  }, 
  {
   "hits": 2, 
   "name": "queensbury, ny"
  }, 
  {
   "hits": 2, 
   "name": "dripping springs, tx"
  }, 
  {
   "hits": 2, 
   "name": "capistrano beach, ca"
  }, 
  {
   "hits": 2, 
   "name": "warwick, ny"
  }, 
  {
   "hits": 2, 
   "name": "landenberg, pa"
  }, 
  {
   "hits": 2, 
   "name": "santa fe, tx"
  }, 
  {
   "hits": 2, 
   "name": "rosemount, mn"
  }, 
  {
   "hits": 2, 
   "name": "nanuet, ny"
  }, 
  {
   "hits": 2, 
   "name": "salisbury, md"
  }, 
  {
   "hits": 2, 
   "name": "kelso, wa"
  }, 
  {
   "hits": 2, 
   "name": "oak park, ca"
  }, 
  {
   "hits": 2, 
   "name": "salem, oh"
  }, 
  {
   "hits": 2, 
   "name": "safety harbor, fl"
  }, 
  {
   "hits": 2, 
   "name": "forestburg, tx"
  }, 
  {
   "hits": 2, 
   "name": "weston, fl"
  }, 
  {
   "hits": 2, 
   "name": "fort myers beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "redmond, or"
  }, 
  {
   "hits": 2, 
   "name": "englewood, fl"
  }, 
  {
   "hits": 2, 
   "name": "harrington park, nj"
  }, 
  {
   "hits": 2, 
   "name": "clinton, ms"
  }, 
  {
   "hits": 2, 
   "name": "west babylon, ny"
  }, 
  {
   "hits": 2, 
   "name": "saint croix falls, wi"
  }, 
  {
   "hits": 2, 
   "name": "safford, az"
  }, 
  {
   "hits": 2, 
   "name": "perkasie, pa"
  }, 
  {
   "hits": 2, 
   "name": "panama city, fl"
  }, 
  {
   "hits": 2, 
   "name": "point roberts, wa"
  }, 
  {
   "hits": 2, 
   "name": "glen burnie, md"
  }, 
  {
   "hits": 2, 
   "name": "loxahatchee, fl"
  }, 
  {
   "hits": 2, 
   "name": "st louis, mo"
  }, 
  {
   "hits": 2, 
   "name": "monticello, fl"
  }, 
  {
   "hits": 2, 
   "name": "sandy, tx"
  }, 
  {
   "hits": 2, 
   "name": "barboursville, wv"
  }, 
  {
   "hits": 2, 
   "name": ", va"
  }, 
  {
   "hits": 2, 
   "name": "massapequa, ny"
  }, 
  {
   "hits": 2, 
   "name": "boaz, al"
  }, 
  {
   "hits": 2, 
   "name": "north salt lake, ut"
  }, 
  {
   "hits": 2, 
   "name": "aberdeen, sd"
  }, 
  {
   "hits": 2, 
   "name": "springfield, vt"
  }, 
  {
   "hits": 2, 
   "name": "maitland, fl"
  }, 
  {
   "hits": 2, 
   "name": "mosinee, wi"
  }, 
  {
   "hits": 2, 
   "name": "west sacramento, ca"
  }, 
  {
   "hits": 2, 
   "name": "cedar city, ut"
  }, 
  {
   "hits": 2, 
   "name": "rosenberg, tx"
  }, 
  {
   "hits": 2, 
   "name": "river edge, nj"
  }, 
  {
   "hits": 2, 
   "name": "ocean springs, ms"
  }, 
  {
   "hits": 2, 
   "name": "roseburg, or"
  }, 
  {
   "hits": 2, 
   "name": "lexington, va"
  }, 
  {
   "hits": 2, 
   "name": "westbury, ny"
  }, 
  {
   "hits": 2, 
   "name": "elk river, mn"
  }, 
  {
   "hits": 2, 
   "name": "paso robles, ca"
  }, 
  {
   "hits": 2, 
   "name": "freehold, nj"
  }, 
  {
   "hits": 2, 
   "name": "rutherford, nj"
  }, 
  {
   "hits": 2, 
   "name": "placentia, ca"
  }, 
  {
   "hits": 2, 
   "name": "la puente, ca"
  }, 
  {
   "hits": 2, 
   "name": "scotch plains, nj"
  }, 
  {
   "hits": 2, 
   "name": "mandeville, la"
  }, 
  {
   "hits": 2, 
   "name": "hopedale, ma"
  }, 
  {
   "hits": 2, 
   "name": "vinton, va"
  }, 
  {
   "hits": 2, 
   "name": "twin falls, id"
  }, 
  {
   "hits": 2, 
   "name": "tigard, or"
  }, 
  {
   "hits": 2, 
   "name": "south easton, ma"
  }, 
  {
   "hits": 2, 
   "name": "hixson, tn"
  }, 
  {
   "hits": 2, 
   "name": "harpers ferry, wv"
  }, 
  {
   "hits": 2, 
   "name": "litchfield park, az"
  }, 
  {
   "hits": 2, 
   "name": "birdsboro, pa"
  }, 
  {
   "hits": 2, 
   "name": "cherry valley, ny"
  }, 
  {
   "hits": 2, 
   "name": "hibbing, mn"
  }, 
  {
   "hits": 2, 
   "name": "duvall, wa"
  }, 
  {
   "hits": 2, 
   "name": "taos, nm"
  }, 
  {
   "hits": 2, 
   "name": "west chester, oh"
  }, 
  {
   "hits": 2, 
   "name": "metamora, il"
  }, 
  {
   "hits": 2, 
   "name": "dunn, nc"
  }, 
  {
   "hits": 2, 
   "name": "brookeville, md"
  }, 
  {
   "hits": 2, 
   "name": "hahira, ga"
  }, 
  {
   "hits": 2, 
   "name": "hillsborough, nj"
  }, 
  {
   "hits": 2, 
   "name": "harleysville, pa"
  }, 
  {
   "hits": 2, 
   "name": "azle, tx"
  }, 
  {
   "hits": 2, 
   "name": "norfolk, ma"
  }, 
  {
   "hits": 2, 
   "name": "chesterton, in"
  }, 
  {
   "hits": 2, 
   "name": "northfield, mn"
  }, 
  {
   "hits": 2, 
   "name": "north yarmouth, me"
  }, 
  {
   "hits": 2, 
   "name": "aliquippa, pa"
  }, 
  {
   "hits": 2, 
   "name": "gloucester city, nj"
  }, 
  {
   "hits": 2, 
   "name": "brookfield, il"
  }, 
  {
   "hits": 2, 
   "name": "east greenwich, ri"
  }, 
  {
   "hits": 2, 
   "name": "langley, wa"
  }, 
  {
   "hits": 2, 
   "name": "unity, me"
  }, 
  {
   "hits": 2, 
   "name": "abbeville, la"
  }, 
  {
   "hits": 2, 
   "name": "milton freewater, or"
  }, 
  {
   "hits": 2, 
   "name": "hingham, ma"
  }, 
  {
   "hits": 2, 
   "name": "fenton, mo"
  }, 
  {
   "hits": 2, 
   "name": "beaumont, ca"
  }, 
  {
   "hits": 2, 
   "name": "saint clair shores, mi"
  }, 
  {
   "hits": 2, 
   "name": "dunedin, fl"
  }, 
  {
   "hits": 2, 
   "name": "graham, nc"
  }, 
  {
   "hits": 2, 
   "name": "davison, mi"
  }, 
  {
   "hits": 2, 
   "name": "clarksburg, wv"
  }, 
  {
   "hits": 2, 
   "name": "frankfort, il"
  }, 
  {
   "hits": 2, 
   "name": "enola, pa"
  }, 
  {
   "hits": 2, 
   "name": "east chicago, in"
  }, 
  {
   "hits": 2, 
   "name": "niagara falls, ny"
  }, 
  {
   "hits": 2, 
   "name": "shelton, ct"
  }, 
  {
   "hits": 2, 
   "name": "coronado, ca"
  }, 
  {
   "hits": 2, 
   "name": "klamath falls, or"
  }, 
  {
   "hits": 2, 
   "name": "berlin, md"
  }, 
  {
   "hits": 2, 
   "name": "taylor, mi"
  }, 
  {
   "hits": 2, 
   "name": "south windsor, ct"
  }, 
  {
   "hits": 2, 
   "name": ", al"
  }, 
  {
   "hits": 2, 
   "name": "saint helens, or"
  }, 
  {
   "hits": 2, 
   "name": "cerritos, ca"
  }, 
  {
   "hits": 2, 
   "name": "westminster, co"
  }, 
  {
   "hits": 2, 
   "name": "butler, nj"
  }, 
  {
   "hits": 2, 
   "name": "hollis, nh"
  }, 
  {
   "hits": 2, 
   "name": "sylvania, oh"
  }, 
  {
   "hits": 2, 
   "name": "wellesley, ma"
  }, 
  {
   "hits": 2, 
   "name": "lincolnton, nc"
  }, 
  {
   "hits": 2, 
   "name": "willow spring, nc"
  }, 
  {
   "hits": 2, 
   "name": "fennville, mi"
  }, 
  {
   "hits": 2, 
   "name": "butler, pa"
  }, 
  {
   "hits": 2, 
   "name": "corona, ny"
  }, 
  {
   "hits": 2, 
   "name": "hauppauge, ny"
  }, 
  {
   "hits": 2, 
   "name": "bonaire, ga"
  }, 
  {
   "hits": 2, 
   "name": "magalia, ca"
  }, 
  {
   "hits": 2, 
   "name": "carmel, ny"
  }, 
  {
   "hits": 2, 
   "name": "elizabethton, tn"
  }, 
  {
   "hits": 2, 
   "name": "mount vernon, ny"
  }, 
  {
   "hits": 2, 
   "name": "washington, mo"
  }, 
  {
   "hits": 2, 
   "name": "bastrop, tx"
  }, 
  {
   "hits": 2, 
   "name": "keystone heights, fl"
  }, 
  {
   "hits": 2, 
   "name": "washington, nj"
  }, 
  {
   "hits": 2, 
   "name": "pontiac, mi"
  }, 
  {
   "hits": 2, 
   "name": "atlantic beach, ny"
  }, 
  {
   "hits": 2, 
   "name": "lansdowne, pa"
  }, 
  {
   "hits": 2, 
   "name": "library, pa"
  }, 
  {
   "hits": 2, 
   "name": "mansfield, tx"
  }, 
  {
   "hits": 2, 
   "name": "paola, ks"
  }, 
  {
   "hits": 2, 
   "name": "dahlonega, ga"
  }, 
  {
   "hits": 2, 
   "name": "ardmore, pa"
  }, 
  {
   "hits": 2, 
   "name": "maineville, oh"
  }, 
  {
   "hits": 2, 
   "name": "washougal, wa"
  }, 
  {
   "hits": 2, 
   "name": "grayslake, il"
  }, 
  {
   "hits": 2, 
   "name": "wynnewood, pa"
  }, 
  {
   "hits": 2, 
   "name": "el monte, ca"
  }, 
  {
   "hits": 2, 
   "name": "blue bell, pa"
  }, 
  {
   "hits": 2, 
   "name": "lake charles, la"
  }, 
  {
   "hits": 2, 
   "name": "willoughby, oh"
  }, 
  {
   "hits": 2, 
   "name": "jacksonville, ar"
  }, 
  {
   "hits": 2, 
   "name": "rockaway, nj"
  }, 
  {
   "hits": 2, 
   "name": "vermillion, sd"
  }, 
  {
   "hits": 2, 
   "name": "chaska, mn"
  }, 
  {
   "hits": 2, 
   "name": "linden, nj"
  }, 
  {
   "hits": 2, 
   "name": "shirley, ny"
  }, 
  {
   "hits": 2, 
   "name": "hyde park, ma"
  }, 
  {
   "hits": 2, 
   "name": "florence, al"
  }, 
  {
   "hits": 2, 
   "name": "litchfield, il"
  }, 
  {
   "hits": 2, 
   "name": "bell, ca"
  }, 
  {
   "hits": 2, 
   "name": "oswego, il"
  }, 
  {
   "hits": 2, 
   "name": "santa rosa beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "cramerton, nc"
  }, 
  {
   "hits": 2, 
   "name": "kalispell, mt"
  }, 
  {
   "hits": 2, 
   "name": "kenner, la"
  }, 
  {
   "hits": 2, 
   "name": "fernandina beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "milford, nh"
  }, 
  {
   "hits": 2, 
   "name": "isanti, mn"
  }, 
  {
   "hits": 2, 
   "name": "alpine, ut"
  }, 
  {
   "hits": 2, 
   "name": "aston, pa"
  }, 
  {
   "hits": 2, 
   "name": "east peoria, il"
  }, 
  {
   "hits": 2, 
   "name": "lawrence, ma"
  }, 
  {
   "hits": 2, 
   "name": "oakland, tn"
  }, 
  {
   "hits": 2, 
   "name": "florence, sc"
  }, 
  {
   "hits": 2, 
   "name": "auburn, ca"
  }, 
  {
   "hits": 2, 
   "name": "mountain home, id"
  }, 
  {
   "hits": 2, 
   "name": "cortland, ny"
  }, 
  {
   "hits": 2, 
   "name": "angels camp, ca"
  }, 
  {
   "hits": 2, 
   "name": "wahiawa, hi"
  }, 
  {
   "hits": 2, 
   "name": "seaside, ca"
  }, 
  {
   "hits": 2, 
   "name": "reedley, ca"
  }, 
  {
   "hits": 2, 
   "name": "jamestown, ny"
  }, 
  {
   "hits": 2, 
   "name": "williamsburg, mi"
  }, 
  {
   "hits": 2, 
   "name": "pahrump, nv"
  }, 
  {
   "hits": 2, 
   "name": "strongsville, oh"
  }, 
  {
   "hits": 2, 
   "name": "bowie, md"
  }, 
  {
   "hits": 2, 
   "name": "monument, co"
  }, 
  {
   "hits": 2, 
   "name": "madison, nj"
  }, 
  {
   "hits": 2, 
   "name": "ottawa, ks"
  }, 
  {
   "hits": 2, 
   "name": "burleson, tx"
  }, 
  {
   "hits": 2, 
   "name": "brevard, nc"
  }, 
  {
   "hits": 2, 
   "name": "texas city, tx"
  }, 
  {
   "hits": 2, 
   "name": "canton, ma"
  }, 
  {
   "hits": 2, 
   "name": "carbondale, co"
  }, 
  {
   "hits": 2, 
   "name": "mohave valley, az"
  }, 
  {
   "hits": 2, 
   "name": "old town, me"
  }, 
  {
   "hits": 2, 
   "name": ", la"
  }, 
  {
   "hits": 2, 
   "name": "morton, il"
  }, 
  {
   "hits": 2, 
   "name": "webster, ny"
  }, 
  {
   "hits": 2, 
   "name": "downey, ca"
  }, 
  {
   "hits": 2, 
   "name": "morris plains, nj"
  }, 
  {
   "hits": 2, 
   "name": "coraopolis, pa"
  }, 
  {
   "hits": 2, 
   "name": "casselberry, fl"
  }, 
  {
   "hits": 2, 
   "name": "bealeton, va"
  }, 
  {
   "hits": 2, 
   "name": "fort washington, md"
  }, 
  {
   "hits": 2, 
   "name": "mandan, nd"
  }, 
  {
   "hits": 2, 
   "name": "poplar bluff, mo"
  }, 
  {
   "hits": 2, 
   "name": "the plains, va"
  }, 
  {
   "hits": 2, 
   "name": "lakeville, ct"
  }, 
  {
   "hits": 2, 
   "name": "woodstock, vt"
  }, 
  {
   "hits": 2, 
   "name": "grand ledge, mi"
  }, 
  {
   "hits": 2, 
   "name": "rocky point, ny"
  }, 
  {
   "hits": 2, 
   "name": "monroe, ny"
  }, 
  {
   "hits": 2, 
   "name": "aurora, oh"
  }, 
  {
   "hits": 2, 
   "name": "angleton, tx"
  }, 
  {
   "hits": 2, 
   "name": "johnstown, ny"
  }, 
  {
   "hits": 2, 
   "name": ", co"
  }, 
  {
   "hits": 2, 
   "name": "excelsior, mn"
  }, 
  {
   "hits": 2, 
   "name": "lancaster, ma"
  }, 
  {
   "hits": 2, 
   "name": "bella vista, ar"
  }, 
  {
   "hits": 2, 
   "name": "beaver falls, pa"
  }, 
  {
   "hits": 2, 
   "name": "cantonment, fl"
  }, 
  {
   "hits": 2, 
   "name": "carrollton, ga"
  }, 
  {
   "hits": 2, 
   "name": "dracut, ma"
  }, 
  {
   "hits": 2, 
   "name": "la porte, tx"
  }, 
  {
   "hits": 2, 
   "name": "ashland, ky"
  }, 
  {
   "hits": 2, 
   "name": "madison, ms"
  }, 
  {
   "hits": 2, 
   "name": "farmington, ct"
  }, 
  {
   "hits": 2, 
   "name": "ponte vedra beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "lakewood, co"
  }, 
  {
   "hits": 2, 
   "name": "milford, mi"
  }, 
  {
   "hits": 2, 
   "name": "peabody, ma"
  }, 
  {
   "hits": 2, 
   "name": "simpsonville, sc"
  }, 
  {
   "hits": 2, 
   "name": "mission hills, ca"
  }, 
  {
   "hits": 2, 
   "name": "campbellsville, ky"
  }, 
  {
   "hits": 2, 
   "name": "feeding hills, ma"
  }, 
  {
   "hits": 2, 
   "name": "desoto, tx"
  }, 
  {
   "hits": 2, 
   "name": "round hill, va"
  }, 
  {
   "hits": 2, 
   "name": "albany, ga"
  }, 
  {
   "hits": 2, 
   "name": "mishawaka, in"
  }, 
  {
   "hits": 2, 
   "name": "haddon heights, nj"
  }, 
  {
   "hits": 2, 
   "name": "fairborn, oh"
  }, 
  {
   "hits": 2, 
   "name": "halethorpe, md"
  }, 
  {
   "hits": 2, 
   "name": "kew gardens, ny"
  }, 
  {
   "hits": 2, 
   "name": "selma, al"
  }, 
  {
   "hits": 2, 
   "name": "flossmoor, il"
  }, 
  {
   "hits": 2, 
   "name": "west springfield, ma"
  }, 
  {
   "hits": 2, 
   "name": "beaufort, sc"
  }, 
  {
   "hits": 2, 
   "name": "flemington, nj"
  }, 
  {
   "hits": 2, 
   "name": "waterloo, in"
  }, 
  {
   "hits": 2, 
   "name": "tryon, nc"
  }, 
  {
   "hits": 2, 
   "name": "new castle, pa"
  }, 
  {
   "hits": 2, 
   "name": "richmond hill, ny"
  }, 
  {
   "hits": 2, 
   "name": "hoffman estates, il"
  }, 
  {
   "hits": 2, 
   "name": "allendale, mi"
  }, 
  {
   "hits": 2, 
   "name": "corbin, ky"
  }, 
  {
   "hits": 2, 
   "name": "ramona, ca"
  }, 
  {
   "hits": 2, 
   "name": "enid, ok"
  }, 
  {
   "hits": 2, 
   "name": "baldwinsville, ny"
  }, 
  {
   "hits": 2, 
   "name": "bristol, nh"
  }, 
  {
   "hits": 2, 
   "name": "bryn mawr, pa"
  }, 
  {
   "hits": 2, 
   "name": "roseville, mi"
  }, 
  {
   "hits": 2, 
   "name": "seminole, fl"
  }, 
  {
   "hits": 2, 
   "name": "white sulphur springs, wv"
  }, 
  {
   "hits": 2, 
   "name": "morristown, tn"
  }, 
  {
   "hits": 2, 
   "name": "clearwater beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "short hills, nj"
  }, 
  {
   "hits": 2, 
   "name": "boyertown, pa"
  }, 
  {
   "hits": 2, 
   "name": "bergenfield, nj"
  }, 
  {
   "hits": 2, 
   "name": "south ozone park, ny"
  }, 
  {
   "hits": 2, 
   "name": "rockwall, tx"
  }, 
  {
   "hits": 2, 
   "name": "madera, ca"
  }, 
  {
   "hits": 2, 
   "name": "willis, tx"
  }, 
  {
   "hits": 2, 
   "name": "pleasant hill, mo"
  }, 
  {
   "hits": 2, 
   "name": "del mar, ca"
  }, 
  {
   "hits": 2, 
   "name": "milledgeville, ga"
  }, 
  {
   "hits": 2, 
   "name": "pinckney, mi"
  }, 
  {
   "hits": 2, 
   "name": "new smyrna beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "bar harbor, me"
  }, 
  {
   "hits": 2, 
   "name": "lebanon, pa"
  }, 
  {
   "hits": 2, 
   "name": "mebane, nc"
  }, 
  {
   "hits": 2, 
   "name": "beckley, wv"
  }, 
  {
   "hits": 2, 
   "name": "auburn, al"
  }, 
  {
   "hits": 2, 
   "name": "floral park, ny"
  }, 
  {
   "hits": 2, 
   "name": "terre haute, in"
  }, 
  {
   "hits": 2, 
   "name": "winter haven, fl"
  }, 
  {
   "hits": 2, 
   "name": "oak harbor, wa"
  }, 
  {
   "hits": 2, 
   "name": "taylors, sc"
  }, 
  {
   "hits": 2, 
   "name": "ellington, ct"
  }, 
  {
   "hits": 2, 
   "name": "somers, ct"
  }, 
  {
   "hits": 2, 
   "name": "malvern, pa"
  }, 
  {
   "hits": 2, 
   "name": "moraga, ca"
  }, 
  {
   "hits": 2, 
   "name": "park ridge, il"
  }, 
  {
   "hits": 2, 
   "name": "watertown, ny"
  }, 
  {
   "hits": 2, 
   "name": "guilford, ct"
  }, 
  {
   "hits": 2, 
   "name": "kapaa, hi"
  }, 
  {
   "hits": 2, 
   "name": "southborough, ma"
  }, 
  {
   "hits": 2, 
   "name": "wharton, nj"
  }, 
  {
   "hits": 2, 
   "name": "dexter, mi"
  }, 
  {
   "hits": 2, 
   "name": ", nc"
  }, 
  {
   "hits": 2, 
   "name": "phillipsburg, nj"
  }, 
  {
   "hits": 2, 
   "name": "north chelmsford, ma"
  }, 
  {
   "hits": 2, 
   "name": "lithia, fl"
  }, 
  {
   "hits": 2, 
   "name": "woodstock, il"
  }, 
  {
   "hits": 2, 
   "name": "alexandria, la"
  }, 
  {
   "hits": 2, 
   "name": "hattiesburg, ms"
  }, 
  {
   "hits": 2, 
   "name": "chelsea, ma"
  }, 
  {
   "hits": 2, 
   "name": "cumberland, md"
  }, 
  {
   "hits": 2, 
   "name": "mooresville, in"
  }, 
  {
   "hits": 2, 
   "name": "orange park, fl"
  }, 
  {
   "hits": 2, 
   "name": "westwood, ma"
  }, 
  {
   "hits": 2, 
   "name": "wheeling, wv"
  }, 
  {
   "hits": 2, 
   "name": "hanford, ca"
  }, 
  {
   "hits": 2, 
   "name": "canyon country, ca"
  }, 
  {
   "hits": 2, 
   "name": "belleville, nj"
  }, 
  {
   "hits": 2, 
   "name": "winchester, ca"
  }, 
  {
   "hits": 2, 
   "name": "glen ridge, nj"
  }, 
  {
   "hits": 2, 
   "name": "gardnerville ranchos, nv"
  }, 
  {
   "hits": 2, 
   "name": "belmar, nj"
  }, 
  {
   "hits": 2, 
   "name": "orange, tx"
  }, 
  {
   "hits": 2, 
   "name": "wayne, nj"
  }, 
  {
   "hits": 2, 
   "name": "prospect heights, il"
  }, 
  {
   "hits": 2, 
   "name": "kendall park, nj"
  }, 
  {
   "hits": 2, 
   "name": "hazel crest, il"
  }, 
  {
   "hits": 2, 
   "name": "middlebury, vt"
  }, 
  {
   "hits": 2, 
   "name": "jacksonville, nc"
  }, 
  {
   "hits": 2, 
   "name": "dayton, tn"
  }, 
  {
   "hits": 2, 
   "name": "georgetown, ky"
  }, 
  {
   "hits": 2, 
   "name": "belvidere, il"
  }, 
  {
   "hits": 2, 
   "name": "canandaigua, ny"
  }, 
  {
   "hits": 2, 
   "name": "camp hill, pa"
  }, 
  {
   "hits": 2, 
   "name": "livingston, tx"
  }, 
  {
   "hits": 2, 
   "name": "auburn, ny"
  }, 
  {
   "hits": 2, 
   "name": "connersville, in"
  }, 
  {
   "hits": 2, 
   "name": "huntsville, tx"
  }, 
  {
   "hits": 2, 
   "name": "cave creek, az"
  }, 
  {
   "hits": 2, 
   "name": "delano, ca"
  }, 
  {
   "hits": 2, 
   "name": "columbia city, in"
  }, 
  {
   "hits": 2, 
   "name": "lake jackson, tx"
  }, 
  {
   "hits": 2, 
   "name": "north haven, ct"
  }, 
  {
   "hits": 2, 
   "name": "american fork, ut"
  }, 
  {
   "hits": 2, 
   "name": "south hamilton, ma"
  }, 
  {
   "hits": 2, 
   "name": "lake grove, ny"
  }, 
  {
   "hits": 2, 
   "name": "urbandale, ia"
  }, 
  {
   "hits": 2, 
   "name": "gorham, me"
  }, 
  {
   "hits": 2, 
   "name": "camden wyoming, de"
  }, 
  {
   "hits": 2, 
   "name": "gonzales, la"
  }, 
  {
   "hits": 2, 
   "name": "staunton, va"
  }, 
  {
   "hits": 2, 
   "name": "central, sc"
  }, 
  {
   "hits": 2, 
   "name": "slidell, la"
  }, 
  {
   "hits": 2, 
   "name": "miller place, ny"
  }, 
  {
   "hits": 2, 
   "name": "paxton, il"
  }, 
  {
   "hits": 2, 
   "name": "apollo beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "monroeville, pa"
  }, 
  {
   "hits": 2, 
   "name": "batavia, il"
  }, 
  {
   "hits": 2, 
   "name": "yorktown heights, ny"
  }, 
  {
   "hits": 2, 
   "name": "itasca, il"
  }, 
  {
   "hits": 2, 
   "name": "jenison, mi"
  }, 
  {
   "hits": 2, 
   "name": "williston, fl"
  }, 
  {
   "hits": 2, 
   "name": "banks, or"
  }, 
  {
   "hits": 2, 
   "name": "forest grove, or"
  }, 
  {
   "hits": 2, 
   "name": "nampa, id"
  }, 
  {
   "hits": 2, 
   "name": "texarkana, tx"
  }, 
  {
   "hits": 2, 
   "name": "chehalis, wa"
  }, 
  {
   "hits": 2, 
   "name": "lamar, co"
  }, 
  {
   "hits": 2, 
   "name": "larned, ks"
  }, 
  {
   "hits": 2, 
   "name": "indian trail, nc"
  }, 
  {
   "hits": 2, 
   "name": "pittsburg, ks"
  }, 
  {
   "hits": 2, 
   "name": "elkhorn, ne"
  }, 
  {
   "hits": 2, 
   "name": "bluffton, sc"
  }, 
  {
   "hits": 2, 
   "name": "massena, ny"
  }, 
  {
   "hits": 2, 
   "name": "fitzwilliam, nh"
  }, 
  {
   "hits": 2, 
   "name": "richmond, tx"
  }, 
  {
   "hits": 2, 
   "name": "hutto, tx"
  }, 
  {
   "hits": 2, 
   "name": "fredonia, ny"
  }, 
  {
   "hits": 2, 
   "name": "mount juliet, tn"
  }, 
  {
   "hits": 2, 
   "name": "monticello, ut"
  }, 
  {
   "hits": 2, 
   "name": "red hook, ny"
  }, 
  {
   "hits": 2, 
   "name": "sauk centre, mn"
  }, 
  {
   "hits": 2, 
   "name": "loma linda, ca"
  }, 
  {
   "hits": 2, 
   "name": "east hartford, ct"
  }, 
  {
   "hits": 2, 
   "name": "freeland, wa"
  }, 
  {
   "hits": 2, 
   "name": "argyle, tx"
  }, 
  {
   "hits": 2, 
   "name": "wauconda, il"
  }, 
  {
   "hits": 2, 
   "name": "lakewood, nj"
  }, 
  {
   "hits": 2, 
   "name": "durand, mi"
  }, 
  {
   "hits": 2, 
   "name": "south fork, pa"
  }, 
  {
   "hits": 2, 
   "name": "meriden, ct"
  }, 
  {
   "hits": 2, 
   "name": "kennebunk, me"
  }, 
  {
   "hits": 2, 
   "name": "coventry, ct"
  }, 
  {
   "hits": 2, 
   "name": "waukegan, il"
  }, 
  {
   "hits": 2, 
   "name": "grand forks, nd"
  }, 
  {
   "hits": 2, 
   "name": "maumee, oh"
  }, 
  {
   "hits": 2, 
   "name": "forest park, il"
  }, 
  {
   "hits": 2, 
   "name": "tolleson, az"
  }, 
  {
   "hits": 2, 
   "name": "madison heights, mi"
  }, 
  {
   "hits": 2, 
   "name": "willow grove, pa"
  }, 
  {
   "hits": 2, 
   "name": "sheffield, al"
  }, 
  {
   "hits": 2, 
   "name": "canton, il"
  }, 
  {
   "hits": 2, 
   "name": "sevierville, tn"
  }, 
  {
   "hits": 2, 
   "name": "alta loma, ca"
  }, 
  {
   "hits": 2, 
   "name": "alachua, fl"
  }, 
  {
   "hits": 2, 
   "name": "macon, ga"
  }, 
  {
   "hits": 2, 
   "name": "el segundo, ca"
  }, 
  {
   "hits": 2, 
   "name": "woodbridge, nj"
  }, 
  {
   "hits": 2, 
   "name": "la grange, il"
  }, 
  {
   "hits": 2, 
   "name": "ringoes, nj"
  }, 
  {
   "hits": 2, 
   "name": "newberry, fl"
  }, 
  {
   "hits": 2, 
   "name": "provincetown, ma"
  }, 
  {
   "hits": 2, 
   "name": "zeeland, mi"
  }, 
  {
   "hits": 2, 
   "name": "maple shade, nj"
  }, 
  {
   "hits": 2, 
   "name": "coldwater, mi"
  }, 
  {
   "hits": 2, 
   "name": "madison, in"
  }, 
  {
   "hits": 2, 
   "name": "philipsburg, pa"
  }, 
  {
   "hits": 2, 
   "name": "nuevo, ca"
  }, 
  {
   "hits": 2, 
   "name": "west orange, nj"
  }, 
  {
   "hits": 2, 
   "name": "allison park, pa"
  }, 
  {
   "hits": 2, 
   "name": "brush, co"
  }, 
  {
   "hits": 2, 
   "name": "north tonawanda, ny"
  }, 
  {
   "hits": 2, 
   "name": "port crane, ny"
  }, 
  {
   "hits": 2, 
   "name": "fort mill, sc"
  }, 
  {
   "hits": 2, 
   "name": "cold spring, ny"
  }, 
  {
   "hits": 2, 
   "name": "liverpool, ny"
  }, 
  {
   "hits": 2, 
   "name": "upland, ca"
  }, 
  {
   "hits": 2, 
   "name": "puryear, tn"
  }, 
  {
   "hits": 2, 
   "name": "beaufort, nc"
  }, 
  {
   "hits": 2, 
   "name": "nipomo, ca"
  }, 
  {
   "hits": 2, 
   "name": "sartell, mn"
  }, 
  {
   "hits": 2, 
   "name": "oconomowoc, wi"
  }, 
  {
   "hits": 2, 
   "name": "rifle, co"
  }, 
  {
   "hits": 2, 
   "name": "coopersville, mi"
  }, 
  {
   "hits": 2, 
   "name": "southgate, mi"
  }, 
  {
   "hits": 2, 
   "name": "stevensville, mi"
  }, 
  {
   "hits": 2, 
   "name": "chesterland, oh"
  }, 
  {
   "hits": 2, 
   "name": "dawsonville, ga"
  }, 
  {
   "hits": 2, 
   "name": "saddle river, nj"
  }, 
  {
   "hits": 2, 
   "name": "mount vernon, wa"
  }, 
  {
   "hits": 2, 
   "name": "drums, pa"
  }, 
  {
   "hits": 2, 
   "name": "waterloo, ia"
  }, 
  {
   "hits": 2, 
   "name": "statesville, nc"
  }, 
  {
   "hits": 2, 
   "name": "marana, az"
  }, 
  {
   "hits": 2, 
   "name": "clarks summit, pa"
  }, 
  {
   "hits": 2, 
   "name": "oshkosh, wi"
  }, 
  {
   "hits": 2, 
   "name": "st petersburg, fl"
  }, 
  {
   "hits": 2, 
   "name": "east haven, ct"
  }, 
  {
   "hits": 2, 
   "name": "winters, ca"
  }, 
  {
   "hits": 2, 
   "name": "pocatello, id"
  }, 
  {
   "hits": 2, 
   "name": "panorama city, ca"
  }, 
  {
   "hits": 2, 
   "name": "gadsden, al"
  }, 
  {
   "hits": 2, 
   "name": "corrales, nm"
  }, 
  {
   "hits": 2, 
   "name": "grandville, mi"
  }, 
  {
   "hits": 2, 
   "name": "belfair, wa"
  }, 
  {
   "hits": 2, 
   "name": "reynoldsburg, oh"
  }, 
  {
   "hits": 2, 
   "name": "ashfield, ma"
  }, 
  {
   "hits": 2, 
   "name": "kiel, wi"
  }, 
  {
   "hits": 2, 
   "name": ", il"
  }, 
  {
   "hits": 2, 
   "name": "cockeysville, md"
  }, 
  {
   "hits": 2, 
   "name": "ayden, nc"
  }, 
  {
   "hits": 2, 
   "name": "royersford, pa"
  }, 
  {
   "hits": 2, 
   "name": "williamston, sc"
  }, 
  {
   "hits": 2, 
   "name": "missouri city, tx"
  }, 
  {
   "hits": 2, 
   "name": "new hartford, ct"
  }, 
  {
   "hits": 2, 
   "name": "williston park, ny"
  }, 
  {
   "hits": 2, 
   "name": "rutland, vt"
  }, 
  {
   "hits": 2, 
   "name": "wiscasset, me"
  }, 
  {
   "hits": 2, 
   "name": "pelham, al"
  }, 
  {
   "hits": 2, 
   "name": "arroyo grande, ca"
  }, 
  {
   "hits": 2, 
   "name": "mckeesport, pa"
  }, 
  {
   "hits": 2, 
   "name": "easton, ct"
  }, 
  {
   "hits": 2, 
   "name": "timberlake, nc"
  }, 
  {
   "hits": 2, 
   "name": "ada, mi"
  }, 
  {
   "hits": 2, 
   "name": "havre de grace, md"
  }, 
  {
   "hits": 2, 
   "name": "kennett square, pa"
  }, 
  {
   "hits": 2, 
   "name": "white house, tn"
  }, 
  {
   "hits": 2, 
   "name": "alliance, oh"
  }, 
  {
   "hits": 2, 
   "name": "stoneham, ma"
  }, 
  {
   "hits": 2, 
   "name": "center sandwich, nh"
  }, 
  {
   "hits": 2, 
   "name": "minot, nd"
  }, 
  {
   "hits": 2, 
   "name": "marco island, fl"
  }, 
  {
   "hits": 2, 
   "name": "wexford, pa"
  }, 
  {
   "hits": 2, 
   "name": "graham, wa"
  }, 
  {
   "hits": 2, 
   "name": "livingston, la"
  }, 
  {
   "hits": 2, 
   "name": "warren, nj"
  }, 
  {
   "hits": 2, 
   "name": "culpeper, va"
  }, 
  {
   "hits": 2, 
   "name": "brookville, oh"
  }, 
  {
   "hits": 2, 
   "name": "rye, ny"
  }, 
  {
   "hits": 2, 
   "name": "middleton, wi"
  }, 
  {
   "hits": 2, 
   "name": "west barnstable, ma"
  }, 
  {
   "hits": 2, 
   "name": "rio, wi"
  }, 
  {
   "hits": 2, 
   "name": "rhinebeck, ny"
  }, 
  {
   "hits": 2, 
   "name": "gastonia, nc"
  }, 
  {
   "hits": 2, 
   "name": "rodeo, ca"
  }, 
  {
   "hits": 2, 
   "name": "seneca, sc"
  }, 
  {
   "hits": 2, 
   "name": "kingston, pa"
  }, 
  {
   "hits": 2, 
   "name": "willimantic, ct"
  }, 
  {
   "hits": 2, 
   "name": "waterford, pa"
  }, 
  {
   "hits": 2, 
   "name": "duxbury, ma"
  }, 
  {
   "hits": 2, 
   "name": "nantucket, ma"
  }, 
  {
   "hits": 2, 
   "name": "fuquay varina, nc"
  }, 
  {
   "hits": 2, 
   "name": "nahant, ma"
  }, 
  {
   "hits": 2, 
   "name": "gulf breeze, fl"
  }, 
  {
   "hits": 2, 
   "name": "greendale, wi"
  }, 
  {
   "hits": 2, 
   "name": "waynesboro, pa"
  }, 
  {
   "hits": 2, 
   "name": "middletown, nj"
  }, 
  {
   "hits": 2, 
   "name": "selden, ny"
  }, 
  {
   "hits": 2, 
   "name": "middletown, ny"
  }, 
  {
   "hits": 2, 
   "name": "evanston, wy"
  }, 
  {
   "hits": 2, 
   "name": "roy, ut"
  }, 
  {
   "hits": 2, 
   "name": "houma, la"
  }, 
  {
   "hits": 2, 
   "name": "slate hill, ny"
  }, 
  {
   "hits": 2, 
   "name": "college place, wa"
  }, 
  {
   "hits": 2, 
   "name": "pfafftown, nc"
  }, 
  {
   "hits": 2, 
   "name": "haslett, mi"
  }, 
  {
   "hits": 2, 
   "name": "buffalo, mn"
  }, 
  {
   "hits": 2, 
   "name": "ottumwa, ia"
  }, 
  {
   "hits": 2, 
   "name": "agoura hills, ca"
  }, 
  {
   "hits": 2, 
   "name": "highland, mi"
  }, 
  {
   "hits": 2, 
   "name": "groton, ct"
  }, 
  {
   "hits": 2, 
   "name": "boylston, ma"
  }, 
  {
   "hits": 2, 
   "name": "manorville, ny"
  }, 
  {
   "hits": 2, 
   "name": "ridgecrest, ca"
  }, 
  {
   "hits": 2, 
   "name": "chisholm, mn"
  }, 
  {
   "hits": 2, 
   "name": "healdsburg, ca"
  }, 
  {
   "hits": 2, 
   "name": "williamsport, pa"
  }, 
  {
   "hits": 2, 
   "name": "big sandy, mt"
  }, 
  {
   "hits": 2, 
   "name": "ridley park, pa"
  }, 
  {
   "hits": 2, 
   "name": "west new york, nj"
  }, 
  {
   "hits": 2, 
   "name": "merchantville, nj"
  }, 
  {
   "hits": 2, 
   "name": "brooktondale, ny"
  }, 
  {
   "hits": 2, 
   "name": "portsmouth, va"
  }, 
  {
   "hits": 2, 
   "name": "odessa, fl"
  }, 
  {
   "hits": 2, 
   "name": ", id"
  }, 
  {
   "hits": 2, 
   "name": "grovetown, ga"
  }, 
  {
   "hits": 2, 
   "name": "lenexa, ks"
  }, 
  {
   "hits": 2, 
   "name": "bourbonnais, il"
  }, 
  {
   "hits": 2, 
   "name": "rocklin, ca"
  }, 
  {
   "hits": 2, 
   "name": "towanda, pa"
  }, 
  {
   "hits": 2, 
   "name": "decatur, al"
  }, 
  {
   "hits": 2, 
   "name": "walpole, ma"
  }, 
  {
   "hits": 2, 
   "name": "boerne, tx"
  }, 
  {
   "hits": 2, 
   "name": "lexington, nc"
  }, 
  {
   "hits": 2, 
   "name": "waipahu, hi"
  }, 
  {
   "hits": 2, 
   "name": "buffalo grove, il"
  }, 
  {
   "hits": 2, 
   "name": "kearny, nj"
  }, 
  {
   "hits": 2, 
   "name": "inver grove heights, mn"
  }, 
  {
   "hits": 2, 
   "name": "belleville, il"
  }, 
  {
   "hits": 2, 
   "name": "sparks, nv"
  }, 
  {
   "hits": 2, 
   "name": "shippensburg, pa"
  }, 
  {
   "hits": 2, 
   "name": "emmaus, pa"
  }, 
  {
   "hits": 2, 
   "name": "southaven, ms"
  }, 
  {
   "hits": 2, 
   "name": "south grafton, ma"
  }, 
  {
   "hits": 2, 
   "name": "port hueneme, ca"
  }, 
  {
   "hits": 2, 
   "name": "manchester, mi"
  }, 
  {
   "hits": 2, 
   "name": "mankato, mn"
  }, 
  {
   "hits": 2, 
   "name": "land o lakes, fl"
  }, 
  {
   "hits": 2, 
   "name": "bridgeton, nj"
  }, 
  {
   "hits": 2, 
   "name": "titusville, pa"
  }, 
  {
   "hits": 2, 
   "name": "ardsley, ny"
  }, 
  {
   "hits": 2, 
   "name": "lacey, wa"
  }, 
  {
   "hits": 2, 
   "name": "trenton, mi"
  }, 
  {
   "hits": 2, 
   "name": "bellmore, ny"
  }, 
  {
   "hits": 2, 
   "name": "greer, sc"
  }, 
  {
   "hits": 2, 
   "name": "christiansburg, va"
  }, 
  {
   "hits": 2, 
   "name": "abington, ma"
  }, 
  {
   "hits": 2, 
   "name": "johnstown, pa"
  }, 
  {
   "hits": 2, 
   "name": "ooltewah, tn"
  }, 
  {
   "hits": 2, 
   "name": "mattapan, ma"
  }, 
  {
   "hits": 2, 
   "name": "southfield, mi"
  }, 
  {
   "hits": 2, 
   "name": "temple city, ca"
  }, 
  {
   "hits": 2, 
   "name": "shelton, wa"
  }, 
  {
   "hits": 2, 
   "name": "blue hill, me"
  }, 
  {
   "hits": 2, 
   "name": "hammond, in"
  }, 
  {
   "hits": 2, 
   "name": "cloquet, mn"
  }, 
  {
   "hits": 2, 
   "name": "cleveland, tn"
  }, 
  {
   "hits": 2, 
   "name": "greencastle, in"
  }, 
  {
   "hits": 2, 
   "name": ", tn"
  }, 
  {
   "hits": 2, 
   "name": "danbury, ct"
  }, 
  {
   "hits": 2, 
   "name": "newfields, nh"
  }, 
  {
   "hits": 2, 
   "name": "elgin, sc"
  }, 
  {
   "hits": 2, 
   "name": "bushnell, fl"
  }, 
  {
   "hits": 2, 
   "name": "novelty, oh"
  }, 
  {
   "hits": 2, 
   "name": "alpine, tx"
  }, 
  {
   "hits": 2, 
   "name": "rosemead, ca"
  }, 
  {
   "hits": 2, 
   "name": "beacon, ny"
  }, 
  {
   "hits": 2, 
   "name": "fishers, in"
  }, 
  {
   "hits": 2, 
   "name": "mcdonough, ga"
  }, 
  {
   "hits": 2, 
   "name": "east stroudsburg, pa"
  }, 
  {
   "hits": 2, 
   "name": "park ridge, nj"
  }, 
  {
   "hits": 2, 
   "name": "sandusky, oh"
  }, 
  {
   "hits": 2, 
   "name": "north billerica, ma"
  }, 
  {
   "hits": 2, 
   "name": "new market, md"
  }, 
  {
   "hits": 2, 
   "name": "ozone park, ny"
  }, 
  {
   "hits": 2, 
   "name": "indian springs, nv"
  }, 
  {
   "hits": 2, 
   "name": "king, nc"
  }, 
  {
   "hits": 2, 
   "name": "slippery rock, pa"
  }, 
  {
   "hits": 2, 
   "name": "boxford, ma"
  }, 
  {
   "hits": 2, 
   "name": "wood ridge, nj"
  }, 
  {
   "hits": 2, 
   "name": "basking ridge, nj"
  }, 
  {
   "hits": 2, 
   "name": "hawthorne, ca"
  }, 
  {
   "hits": 2, 
   "name": "morris, il"
  }, 
  {
   "hits": 2, 
   "name": "arnold, mo"
  }, 
  {
   "hits": 2, 
   "name": "new river, az"
  }, 
  {
   "hits": 2, 
   "name": "smithtown, ny"
  }, 
  {
   "hits": 2, 
   "name": "crossville, tn"
  }, 
  {
   "hits": 2, 
   "name": "del rio, tx"
  }, 
  {
   "hits": 2, 
   "name": "prattville, al"
  }, 
  {
   "hits": 2, 
   "name": "arlington, wa"
  }, 
  {
   "hits": 2, 
   "name": "windermere, fl"
  }, 
  {
   "hits": 2, 
   "name": "hanson, ma"
  }, 
  {
   "hits": 2, 
   "name": "huntingtown, md"
  }, 
  {
   "hits": 2, 
   "name": "sayville, ny"
  }, 
  {
   "hits": 2, 
   "name": "plainfield, nj"
  }, 
  {
   "hits": 2, 
   "name": "pleasant prairie, wi"
  }, 
  {
   "hits": 2, 
   "name": "millis, ma"
  }, 
  {
   "hits": 2, 
   "name": "lake in the hills, il"
  }, 
  {
   "hits": 2, 
   "name": "jensen beach, fl"
  }, 
  {
   "hits": 2, 
   "name": "cheney, wa"
  }, 
  {
   "hits": 2, 
   "name": "pennsauken, nj"
  }, 
  {
   "hits": 2, 
   "name": "newington, ct"
  }, 
  {
   "hits": 2, 
   "name": "mukilteo, wa"
  }, 
  {
   "hits": 2, 
   "name": "flint, mi"
  }, 
  {
   "hits": 2, 
   "name": "lynnwood, wa"
  }, 
  {
   "hits": 2, 
   "name": "bridgeport, ct"
  }, 
  {
   "hits": 2, 
   "name": "casper, wy"
  }, 
  {
   "hits": 2, 
   "name": "hazel park, mi"
  }, 
  {
   "hits": 2, 
   "name": "driftwood, tx"
  }, 
  {
   "hits": 2, 
   "name": "union, nj"
  }, 
  {
   "hits": 2, 
   "name": "ely, mn"
  }, 
  {
   "hits": 2, 
   "name": "ellensburg, wa"
  }, 
  {
   "hits": 2, 
   "name": "fountain hills, az"
  }, 
  {
   "hits": 2, 
   "name": "robbinsville, nj"
  }, 
  {
   "hits": 2, 
   "name": "kings beach, ca"
  }, 
  {
   "hits": 2, 
   "name": "bethpage, ny"
  }, 
  {
   "hits": 2, 
   "name": "seguin, tx"
  }, 
  {
   "hits": 2, 
   "name": "waynesboro, va"
  }, 
  {
   "hits": 2, 
   "name": "punta gorda, fl"
  }, 
  {
   "hits": 2, 
   "name": "millersville, md"
  }, 
  {
   "hits": 2, 
   "name": "palmer, ak"
  }, 
  {
   "hits": 2, 
   "name": "taylorsville, ky"
  }, 
  {
   "hits": 2, 
   "name": "pomona, ny"
  }, 
  {
   "hits": 2, 
   "name": "bailey, co"
  }, 
  {
   "hits": 2, 
   "name": "the villages, fl"
  }, 
  {
   "hits": 2, 
   "name": "bloomfield, in"
  }, 
  {
   "hits": 2, 
   "name": "granger, in"
  }, 
  {
   "hits": 2, 
   "name": "napoleon, oh"
  }, 
  {
   "hits": 2, 
   "name": "sheridan, wy"
  }, 
  {
   "hits": 2, 
   "name": "thompsontown, pa"
  }, 
  {
   "hits": 2, 
   "name": "sturbridge, ma"
  }, 
  {
   "hits": 2, 
   "name": "fairhaven, ma"
  }, 
  {
   "hits": 2, 
   "name": "monroe, nc"
  }, 
  {
   "hits": 2, 
   "name": "bristol, tn"
  }, 
  {
   "hits": 2, 
   "name": "kamuela, hi"
  }, 
  {
   "hits": 2, 
   "name": "newburgh, in"
  }, 
  {
   "hits": 2, 
   "name": "florham park, nj"
  }, 
  {
   "hits": 2, 
   "name": "aldie, va"
  }, 
  {
   "hits": 2, 
   "name": "new hope, pa"
  }, 
  {
   "hits": 2, 
   "name": "gilroy, ca"
  }, 
  {
   "hits": 2, 
   "name": "solon, oh"
  }, 
  {
   "hits": 2, 
   "name": "merrillville, in"
  }, 
  {
   "hits": 2, 
   "name": "skaneateles, ny"
  }, 
  {
   "hits": 2, 
   "name": "joplin, mo"
  }, 
  {
   "hits": 2, 
   "name": "wyncote, pa"
  }, 
  {
   "hits": 2, 
   "name": "gaffney, sc"
  }, 
  {
   "hits": 2, 
   "name": "new ulm, mn"
  }, 
  {
   "hits": 2, 
   "name": "berwyn, il"
  }, 
  {
   "hits": 2, 
   "name": "somerset, ma"
  }, 
  {
   "hits": 2, 
   "name": "madison, tn"
  }, 
  {
   "hits": 2, 
   "name": "jeffersonville, in"
  }, 
  {
   "hits": 2, 
   "name": "chagrin falls, oh"
  }, 
  {
   "hits": 2, 
   "name": "pontiac, il"
  }, 
  {
   "hits": 2, 
   "name": "universal city, tx"
  }, 
  {
   "hits": 2, 
   "name": "blythe, ca"
  }, 
  {
   "hits": 2, 
   "name": "ketchum, id"
  }, 
  {
   "hits": 2, 
   "name": "villa park, ca"
  }, 
  {
   "hits": 2, 
   "name": "gansevoort, ny"
  }, 
  {
   "hits": 2, 
   "name": "belchertown, ma"
  }, 
  {
   "hits": 2, 
   "name": "middle grove, ny"
  }, 
  {
   "hits": 2, 
   "name": "palmetto, fl"
  }, 
  {
   "hits": 2, 
   "name": "san ysidro, ca"
  }, 
  {
   "hits": 2, 
   "name": "allentown, pa"
  }, 
  {
   "hits": 2, 
   "name": "pacific grove, ca"
  }, 
  {
   "hits": 2, 
   "name": "east hampton, ct"
  }, 
  {
   "hits": 2, 
   "name": "la canada flintridge, ca"
  }, 
  {
   "hits": 2, 
   "name": "council bluffs, ia"
  }, 
  {
   "hits": 2, 
   "name": "blountville, tn"
  }, 
  {
   "hits": 2, 
   "name": "hayesville, nc"
  }, 
  {
   "hits": 2, 
   "name": "huntley, il"
  }, 
  {
   "hits": 2, 
   "name": "kings park, ny"
  }, 
  {
   "hits": 2, 
   "name": "cheverly, md"
  }, 
  {
   "hits": 2, 
   "name": "elkhorn, wi"
  }, 
  {
   "hits": 2, 
   "name": "chambersburg, pa"
  }, 
  {
   "hits": 2, 
   "name": "bonita, ca"
  }, 
  {
   "hits": 2, 
   "name": "la quinta, ca"
  }, 
  {
   "hits": 2, 
   "name": "old saybrook, ct"
  }, 
  {
   "hits": 2, 
   "name": "mason, mi"
  }, 
  {
   "hits": 2, 
   "name": "winfield, ks"
  }, 
  {
   "hits": 2, 
   "name": "hazelwood, mo"
  }, 
  {
   "hits": 2, 
   "name": "millbury, ma"
  }, 
  {
   "hits": 2, 
   "name": "bellefontaine, oh"
  }, 
  {
   "hits": 2, 
   "name": "north bend, or"
  }, 
  {
   "hits": 2, 
   "name": "burton, mi"
  }, 
  {
   "hits": 2, 
   "name": "mill spring, nc"
  }, 
  {
   "hits": 2, 
   "name": "pico rivera, ca"
  }, 
  {
   "hits": 2, 
   "name": "advance, nc"
  }, 
  {
   "hits": 2, 
   "name": "santa teresa, nm"
  }, 
  {
   "hits": 2, 
   "name": "maple valley, wa"
  }, 
  {
   "hits": 2, 
   "name": "antioch, il"
  }, 
  {
   "hits": 2, 
   "name": "lexington, sc"
  }, 
  {
   "hits": 2, 
   "name": "south boston, va"
  }, 
  {
   "hits": 2, 
   "name": "rehoboth, ma"
  }, 
  {
   "hits": 2, 
   "name": "montgomery village, md"
  }, 
  {
   "hits": 2, 
   "name": "whitinsville, ma"
  }, 
  {
   "hits": 2, 
   "name": "medford, nj"
  }, 
  {
   "hits": 2, 
   "name": "rock springs, wy"
  }, 
  {
   "hits": 2, 
   "name": "lenoir city, tn"
  }, 
  {
   "hits": 2, 
   "name": "new providence, nj"
  }, 
  {
   "hits": 2, 
   "name": "woodstock, ct"
  }, 
  {
   "hits": 2, 
   "name": "queens village, ny"
  }, 
  {
   "hits": 2, 
   "name": "highland, ny"
  }, 
  {
   "hits": 2, 
   "name": "woodhaven, ny"
  }, 
  {
   "hits": 2, 
   "name": "latrobe, pa"
  }, 
  {
   "hits": 2, 
   "name": "cedar creek, tx"
  }, 
  {
   "hits": 2, 
   "name": "hobart, in"
  }, 
  {
   "hits": 2, 
   "name": "fayetteville, ny"
  }, 
  {
   "hits": 2, 
   "name": "jessup, md"
  }, 
  {
   "hits": 2, 
   "name": "endicott, ny"
  }, 
  {
   "hits": 2, 
   "name": "mount carmel, pa"
  }, 
  {
   "hits": 2, 
   "name": "north attleboro, ma"
  }, 
  {
   "hits": 2, 
   "name": "brighton, tn"
  }, 
  {
   "hits": 2, 
   "name": "west des moines, ia"
  }, 
  {
   "hits": 2, 
   "name": "hockessin, de"
  }, 
  {
   "hits": 2, 
   "name": "bronxville, ny"
  }, 
  {
   "hits": 2, 
   "name": "bolton, ma"
  }, 
  {
   "hits": 2, 
   "name": "paris, il"
  }, 
  {
   "hits": 2, 
   "name": "chippewa falls, wi"
  }, 
  {
   "hits": 2, 
   "name": "amherst, nh"
  }, 
  {
   "hits": 2, 
   "name": "pescadero, ca"
  }, 
  {
   "hits": 2, 
   "name": "clarksburg, md"
  }, 
  {
   "hits": 2, 
   "name": "lebanon, nj"
  }, 
  {
   "hits": 2, 
   "name": "lebanon, nh"
  }, 
  {
   "hits": 2, 
   "name": "rock falls, il"
  }, 
  {
   "hits": 2, 
   "name": "paradise, ca"
  }, 
  {
   "hits": 2, 
   "name": "springville, ny"
  }, 
  {
   "hits": 2, 
   "name": "pahoa, hi"
  }, 
  {
   "hits": 2, 
   "name": "sandia park, nm"
  }, 
  {
   "hits": 2, 
   "name": "wenham, ma"
  }, 
  {
   "hits": 2, 
   "name": "carthage, mo"
  }, 
  {
   "hits": 2, 
   "name": "goshen, in"
  }, 
  {
   "hits": 2, 
   "name": "foothill ranch, ca"
  }, 
  {
   "hits": 2, 
   "name": "mulberry, fl"
  }, 
  {
   "hits": 2, 
   "name": "clawson, mi"
  }, 
  {
   "hits": 2, 
   "name": "stratford, ct"
  }, 
  {
   "hits": 2, 
   "name": "somerville, nj"
  }, 
  {
   "hits": 2, 
   "name": "newtown, pa"
  }, 
  {
   "hits": 2, 
   "name": "milford, de"
  }, 
  {
   "hits": 2, 
   "name": "huntersville, nc"
  }, 
  {
   "hits": 2, 
   "name": "park city, ut"
  }, 
  {
   "hits": 2, 
   "name": "lincoln, ca"
  }, 
  {
   "hits": 2, 
   "name": "paradise valley, az"
  }, 
  {
   "hits": 2, 
   "name": "littleton, ma"
  }, 
  {
   "hits": 2, 
   "name": "pekin, il"
  }, 
  {
   "hits": 2, 
   "name": "mayer, az"
  }, 
  {
   "hits": 2, 
   "name": "south el monte, ca"
  }, 
  {
   "hits": 2, 
   "name": "tinley park, il"
  }, 
  {
   "hits": 2, 
   "name": "conway, sc"
  }, 
  {
   "hits": 2, 
   "name": "randolph, nj"
  }, 
  {
   "hits": 2, 
   "name": "joshua tree, ca"
  }, 
  {
   "hits": 2, 
   "name": "saugerties, ny"
  }, 
  {
   "hits": 2, 
   "name": "lake peekskill, ny"
  }, 
  {
   "hits": 2, 
   "name": "reisterstown, md"
  }, 
  {
   "hits": 2, 
   "name": "langhorne, pa"
  }, 
  {
   "hits": 2, 
   "name": "highland, in"
  }, 
  {
   "hits": 2, 
   "name": "patchogue, ny"
  }, 
  {
   "hits": 2, 
   "name": "landers, ca"
  }, 
  {
   "hits": 2, 
   "name": "glenshaw, pa"
  }, 
  {
   "hits": 2, 
   "name": "morehead, ky"
  }, 
  {
   "hits": 2, 
   "name": "wendell, nc"
  }, 
  {
   "hits": 2, 
   "name": "middlebury, ct"
  }, 
  {
   "hits": 2, 
   "name": "bristol, ri"
  }, 
  {
   "hits": 2, 
   "name": "new london, ct"
  }, 
  {
   "hits": 2, 
   "name": "deltona, fl"
  }, 
  {
   "hits": 2, 
   "name": "la vergne, tn"
  }, 
  {
   "hits": 2, 
   "name": "miccosukee cpo, fl"
  }, 
  {
   "hits": 2, 
   "name": "spring grove, pa"
  }, 
  {
   "hits": 2, 
   "name": "tooele, ut"
  }, 
  {
   "hits": 2, 
   "name": "osseo, mn"
  }, 
  {
   "hits": 2, 
   "name": "parrish, fl"
  }, 
  {
   "hits": 2, 
   "name": "hudson, oh"
  }, 
  {
   "hits": 2, 
   "name": "rockport, me"
  }, 
  {
   "hits": 2, 
   "name": "south plainfield, nj"
  }, 
  {
   "hits": 2, 
   "name": "westchester, il"
  }, 
  {
   "hits": 2, 
   "name": "southington, ct"
  }, 
  {
   "hits": 2, 
   "name": "cummington, ma"
  }, 
  {
   "hits": 2, 
   "name": "elk grove village, il"
  }, 
  {
   "hits": 2, 
   "name": "amityville, ny"
  }, 
  {
   "hits": 2, 
   "name": "lewiston, me"
  }, 
  {
   "hits": 2, 
   "name": "holland, oh"
  }, 
  {
   "hits": 2, 
   "name": "sandwich, ma"
  }, 
  {
   "hits": 2, 
   "name": "kapolei, hi"
  }, 
  {
   "hits": 2, 
   "name": "clinton, wa"
  }, 
  {
   "hits": 2, 
   "name": "bow, wa"
  }, 
  {
   "hits": 2, 
   "name": "douglas, ma"
  }, 
  {
   "hits": 2, 
   "name": "boyne city, mi"
  }, 
  {
   "hits": 2, 
   "name": "albemarle, nc"
  }, 
  {
   "hits": 2, 
   "name": "long island, ny"
  }, 
  {
   "hits": 2, 
   "name": "danville, il"
  }, 
  {
   "hits": 2, 
   "name": "hull, ma"
  }, 
  {
   "hits": 2, 
   "name": "henderson, co"
  }, 
  {
   "hits": 2, 
   "name": "clayton, nc"
  }, 
  {
   "hits": 2, 
   "name": "battle ground, wa"
  }, 
  {
   "hits": 2, 
   "name": "sapulpa, ok"
  }, 
  {
   "hits": 2, 
   "name": "plainfield, in"
  }, 
  {
   "hits": 2, 
   "name": "seymour, ct"
  }, 
  {
   "hits": 2, 
   "name": "makawao, hi"
  }, 
  {
   "hits": 2, 
   "name": "newburgh, ny"
  }
 ]
};
